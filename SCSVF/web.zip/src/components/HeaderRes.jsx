import React from "react";
import profileIcon from "../assets/usuario.png";
import { useNavigate } from "react-router-dom";

const Banner = ({ onLogout }) => {

  const handleLogout = () => {
    localStorage.removeItem("token");
    console.log("Sesión cerrada"); // Verifica en la consola
    navigate("/");
  };
  
  const navigate = useNavigate();
  const styles = {
    header: {
      position: "fixed", // <- cambia esto de "absolute" a "fixed"
      top: 0,
      left: 0,
      zIndex: 1000, // <- aseguramos que esté por encima de todo
      height: "70px",
      width: "100%",
      backgroundColor: "#f2f2f2",
      padding: "16px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      boxSizing: "border-box",
      boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.1)" // opcional para darle profundidad
    },
    logo: {
      fontWeight: "bold",
      fontSize: "25px",
      color: "black",
      margin: 0,
      cursor: "pointer",
      marginLeft: 100
    },
    logoutContainer: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
    },
    logoutButton: {
      backgroundColor: "#4A1004",
      color: "white",
      padding: "8px 16px",
      border: "none",
      borderRadius: "999px",
      fontSize: "14px",
      fontWeight: "bold",
      height: "40px",
      cursor: "pointer",
    },
    logoutIcon: {
      width: "36px",
      height: "36px",
      cursor: "pointer",
      transition: "transform 0.2s",
    },
  };

  return (
    <div style={styles.header}>
      <h1 style={styles.logo} onClick={() => navigate("/resident/resident-home")}>SCSVF</h1>
      <div style={styles.logoutContainer}>
        <button style={styles.logoutButton} onClick={onLogout}>Cerrar sesión</button>
        <img
          src={profileIcon}
          alt="Perfil"
          style={styles.logoutIcon}
          onClick={() => navigate("/resident/profile")}
        />
      </div>
    </div>
  );
};

export default Banner;
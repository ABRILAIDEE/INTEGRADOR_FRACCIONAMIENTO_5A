import { Navigate, useLocation } from "react-router-dom";

const PrivateRoute = ({ children, allowedRole }) => {
  const token = useMemo(() => localStorage.getItem("token"), []);
  const role = useMemo(() => localStorage.getItem("role"), []);  
  const location = useLocation();

  if (!token || !role) {
    return <Navigate to="/scsvf/resident" state={{ from: location }} replace />;
  }

  if (role !== allowedRole) {
    const redirectHome = role === "ADMIN" ? "/admin/admin-home" : "/resident/resident-home";
    return <Navigate to={redirectHome} replace />;
  }

  return children;
};

export default PrivateRoute;
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import guard from "../assets/policemen.png";
import group from "../assets/multiple-users-silhouette.png";
import map from "../assets/map.png";
import home from "../assets/home.png";
import user from "../assets/usuario.png"

const SidebarRes = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const toggleSidebar = () => setOpen(!open);

  const styles = {
    container: {
      position: "fixed",
      top: 0,
      left: open ? 0 : "-250px",
      height: "100vh",
      width: "250px",
      backgroundColor: "#4A1004",
      color: "white",
      transition: "left 0.3s ease",
      padding: "20px",
      zIndex: 10000,
      display: "flex",
      flexDirection: "column",
    },
    overlay: {
      position: "fixed",
      top: 0,
      left: 0,
      width: open ? "100vw" : "0",
      height: "100vh",
      backgroundColor: "rgba(0,0,0,0.3)",
      transition: "width 0.3s ease",
      zIndex: 9999,
      display: open ? "block" : "none",
    },
    button: {
      position: "fixed",
      top: 10,
      left: 60,
      zIndex: 10001,
      fontSize: 30,
      background: "none",
      border: "none",
      color: "#4A1004",
      cursor: "pointer",
    },
    link: {
      margin: "15px 0",
      fontSize: "18px",
      cursor: "pointer",
      borderBottom: "1px solid white",
      paddingBottom: 8,
      fontWeight: 'bold'
    },
    smallIcon: {
      height: 20,
      width: 20,
      marginRight: 15,

    }
  };

  const handleNavigation = (path) => {
    navigate(path);
    toggleSidebar(); // cerrar después de hacer click
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    console.log("Sesión cerrada"); // Verifica en la consola
    navigate("/");
  };

  return (
    <>
      <button style={styles.button} onClick={toggleSidebar}>☰</button>

      <div style={styles.overlay} onClick={toggleSidebar}></div>

      <div style={styles.container}>
        <h2>Menú</h2>
        <div style={styles.link} onClick={() => handleNavigation("/resident/resident-home")}>
          Página principal
          </div>
        <div style={styles.link} onClick={() => handleNavigation("/resident/create-visit")}>
          <img src={home} style={styles.smallIcon} />
          Crear visitas
        </div>
        <div style={styles.link} onClick={() => handleNavigation("/resident/visits")}>
          <img src={map} style={styles.smallIcon} />
          Mis visitas
        </div>
        <div style={styles.link} onClick={() => handleNavigation("/resident/profile")}>
        <img src={user} style={styles.smallIcon} />
          Perfil
        </div>
        <div style={styles.link} onClick={handleLogout}>
          Cerrar sesión
        </div>
      </div>
    </>
  );
};

export default SidebarRes;

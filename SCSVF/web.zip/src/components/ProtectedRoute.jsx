import { useNavigate, Navigate } from "react-router-dom";
import {jwtDecode} from "jwt-decode";

const ProtectedRoute = ({ children, requiredRole }) => {
  const token = localStorage.getItem("token");
  const rol = localStorage.getItem("role");

  if (!token || !rol) {
    return <Navigate to="/scsvf/admin" />; // o "/scsvf/resident"
  }

  try {
    const decoded = jwtDecode(token);
    const isExpired = decoded.exp * 1000 < Date.now();

    if (isExpired) {
      localStorage.clear();
      return <Navigate to="/scsvf/admin" />;
    }

    if (rol !== requiredRole) {
      // Redirige al home de su rol si intenta entrar al otro
      if (rol === "RESIDENTE") {
        return <Navigate to="/resident/resident-home" />;
      }
      if (rol === "ADMIN") {
        return <Navigate to="/admin/admin-home" />;
      }
    }

    return children;

  } catch (e) {
    localStorage.clear();
    return <Navigate to="/scsvf/admin" />;
  }
};


export default ProtectedRoute;

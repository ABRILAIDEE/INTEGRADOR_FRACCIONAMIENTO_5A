import { Navigate } from "react-router-dom";

const PublicRoute = ({ children }) => {
  const token = localStorage.getItem("token");
  const rol = localStorage.getItem("role");

  const roleMap = {
    ADMIN: "admin",
    RESIDENTE: "resident",
  };

  if (token && rol && roleMap[rol]) {
    const path = roleMap[rol];
    return <Navigate to={`/${path}/${path}-home`} />;
  }

  return children;
};

export default PublicRoute;
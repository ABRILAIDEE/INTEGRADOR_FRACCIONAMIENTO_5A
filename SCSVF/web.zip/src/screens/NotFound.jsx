// src/components/NotFound.jsx
import React from "react";
import { useNavigate } from "react-router-dom";

const NotFound = () => {
  const navigate = useNavigate();

  return (
    <div
      style={{
        height: "100vh",
        backgroundColor: "#f8f8f8",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        fontFamily: "Arial, sans-serif",
        textAlign: "center",
        padding: "1rem",
      }}
    >
      <h1 style={{ fontSize: "6rem", margin: 0, color: "#F09560" }}>404</h1>
      <h2 style={{ marginTop: "0.5rem", marginBottom: "1rem" }}>
        Página no encontrada
      </h2>
      <p>La ruta que intentaste acceder no existe.</p>
      <button
        style={{
          marginTop: "2rem",
          padding: "10px 20px",
          fontSize: "16px",
          borderRadius: "999px",
          border: "none",
          backgroundColor: "#F09560",
          color: "#fff",
          cursor: "pointer",
        }}
        onClick={() => {
          const rol = localStorage.getItem("rol");
          if (rol) {
            navigate(`/${rol.toLowerCase()}/${rol.toLowerCase()}-home`);
          } else {
            navigate("/scsvf/resident");
          }
        }}        
      >
        Ir al inicio
      </button>
    </div>
  );
};

export default NotFound;

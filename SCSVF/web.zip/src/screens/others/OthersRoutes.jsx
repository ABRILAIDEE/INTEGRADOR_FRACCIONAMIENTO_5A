
import React from "react";
import { Routes, Route } from "react-router-dom";
import TempCreateQR from "./TempCreateQR";
import TempCreateVisit from "./TempCreateVisit";
import Unauthorized from "../Unauthorized";
import AdminLogin from "../admin/AdminLogin";
import ResidentLogin from "../residente/ResidenteLogin";
import ResidentVerificarCodigo from "../residente/ResidentVerificarCodigo";
import PublicRoute from "../../components/PublicRoute";
import NotFound from "../NotFound";

const OthersRoute = () => {
  return (
    <Routes>
      <Route
        path="/admin"
        element={
          <PublicRoute>
            <AdminLogin />
          </PublicRoute>
        }
      />
      <Route
        path="/resident"
        element={
          <PublicRoute>
            <ResidentLogin />
          </PublicRoute>
        }
      />
      <Route path="resident/login-code" element={<ResidentVerificarCodigo />} />
      <Route path="temp-create" element={<TempCreateVisit />} />
      <Route path="temp-qr" element={<TempCreateQR />} />
      <Route path="unauthorized" element={<Unauthorized />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default OthersRoute;
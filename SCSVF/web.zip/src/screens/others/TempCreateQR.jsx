import { QRCodeCanvas } from "qrcode.react";
import { useLocation, useNavigate } from "react-router-dom";
import { useRef, useEffect, useState } from "react";
import QRCode from "qrcode";

const styles = {
  container: {
    width: "100%",
    minHeight: "100vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "fixed",
    fontFamily: "sans-serif",
    left: 0,
    top:0
  },
  titleContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    position: 'relative',
    margin: '40px 0',
  },
  goBackButtonWrapper: {
    position: 'absolute',
    left: 200,
    top: '50%',
    transform: 'translateY(-50%)'
  },
  title: {
    fontSize: 48,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#000',
    margin: 0
  },
  qrContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: '350px',
    height: '350px',
    backgroundColor: '#fff',
    borderRadius: '10px',
    padding: '20px',
    marginBottom: '40px',
    marginTop: "-40px"
  },
  shareButton: {
    backgroundColor: '#fff',
    color: '#000',
    padding: '15px 30px',
    border: 'none',
    borderRadius: '30px',
    fontSize: '18px',
    fontWeight: 'bold',
    cursor: 'pointer',
    width: '350px',
    textAlign: 'center',
  },
  goBackButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#591202',
    color: 'white',
    border: 'none',
    borderRadius: 35,
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: 16,
    boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
    transition: '0.3s ease',
    whiteSpace: 'nowrap',
    width: 100
  }
};

export default function TempCreateQR() {


  const navigate = useNavigate();
  const location = useLocation();
  const qrRef = useRef(null);

  const qrUrl = location.state?.qrUrl;

  useEffect(() => {
    if (!qrUrl) {
      navigate("/unauthorized");
    }
  }, [qrUrl, navigate]);


  const [downloading, setDownloading] = useState(false);


const handleDownloadQR = async () => {
  setDownloading(true);

  try {
    const qrImageUrl = await QRCode.toDataURL(qrUrl, {
      width: 300,
      margin: 1,
      color: {
        dark: "#000000",
        light: "#FFFFFF"
      }
    });

    const size = 300;
    const padding = 20;
    const totalHeight = size + padding * 2 + 80;
    const totalWidth = size + padding * 2;

    const canvas = document.createElement("canvas");
    canvas.width = totalWidth;
    canvas.height = totalHeight;
    const ctx = canvas.getContext("2d");

    // Fondo blanco
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, totalWidth, totalHeight);

    // Título
    ctx.fillStyle = "#000000";
    ctx.font = "bold 24px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("SCSVF", totalWidth / 2, 30);

    // Dibujar QR
    const img = new Image();
    img.onload = () => {
      ctx.drawImage(img, padding, 50, size, size);

      // Leyenda
      ctx.fillStyle = "#333";
      ctx.font = "italic 14px sans-serif";
      ctx.fillText("No lo compartas con nadie", totalWidth / 2, totalHeight - 20);

      // Descargar imagen
      const finalUrl = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = finalUrl;
      a.download = "codigo_qr_visita.png";
      a.click();

      setDownloading(false);
    };
    img.src = qrImageUrl;

  } catch (err) {
    console.error("Error generando el QR:", err);
    setDownloading(false);
  }
};



  if (!qrUrl) {
    return <div>No se proporcionó una URL para generar el QR.</div>;
  }

  const handleExit = () => {
    navigate("/scsvf/admin"); // o login si prefieres
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  useEffect(() => {
    if (!qrUrl) {
      navigate("/unauthorized");
    }
  }, [qrUrl, navigate]);


  return (
    <div style={styles.container}>
      <div style={styles.titleContainer}>
        <div style={styles.goBackButtonWrapper}>
          <button
            style={styles.goBackButton}
            onClick={handleExit}
          >
            Salir
          </button>
        </div>
        <h1 style={styles.title}>QR de la visita</h1>
      </div>
      <div style={styles.qrContainer} ref={qrRef}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <h2 style={{ marginBottom: 10, fontSize: 24, fontWeight: "bold", color: "#000" }}>SCSVF</h2>
          <QRCodeCanvas value={qrUrl} size={200} level="H" bgColor="#ffffff" />
          <p style={{ marginTop: 10, fontSize: 14, color: "#333", fontStyle: "italic" }}>
            No lo compartas con nadie
          </p>
        </div>
      </div>
      <button
        onClick={handleDownloadQR}
        style={styles.shareButton}
        disabled={downloading}
      >
        {downloading ? "Descargando..." : "Descargar QR"}
      </button>

    </div>
  );
}

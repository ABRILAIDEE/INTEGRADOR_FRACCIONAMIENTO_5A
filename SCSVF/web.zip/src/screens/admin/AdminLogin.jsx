
import React, { useState } from "react";
import axios from "axios";
import userIcon from "../../assets/usuario.png";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import {jwtDecode} from "jwt-decode";
import 'react-toastify/dist/ReactToastify.css';

const styles = {
  container: {
    width: "100%",
    minHeight: "100vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "fixed",
    fontFamily: "sans-serif",
    left: 0,
    top:0
  },
  header: {
    position: "absolute",
    top: 0,
    left: 0,
    height: "70px",
    width: "100%",
    backgroundColor: "#f2f2f2",
    padding: "16px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    boxSizing: "border-box",
  },
  logo: {
    fontWeight: "bold",
    fontSize: "25px",
    color: "black",
    margin: 0,
  },
  adminButton: {
    backgroundColor: "#4A1004",
    color: "white",
    padding: "8px 16px",
    border: "none",
    borderRadius: "999px",
    fontSize: "14px",
    fontWeight: "bold",
    height: "40px",
    cursor: "pointer",
  },
  loginBox: {
    marginTop: "60px",
    textAlign: "center",
  },
  icon: {
    marginBottom: "20px",
  },
  iconImg: {
    width: "200px",
    height: "200px",
    marginBottom: "-10px",
    objectFit: "contain",
  },
  titulo: {
    margin: "15px",
    fontSize: "50px",
    color: "black",
  },
  inputCode: {
    display: "block",
    margin: "0 auto 16px auto",
    padding: "12px 20px",
    borderRadius: "999px",
    width: "460px",
    textAlign: "center",
    backgroundColor: "#FFFFFF",
    fontSize: "16px",
    color: "black",
    border: "none",
  },
  submitButton: {
    display: "block",
    margin: "0 auto",
    backgroundColor: "#591202",
    color: "white",
    padding: "12px 20px",
    width: "500px",
    height: "40px",
    border: "none",
    borderRadius: "999px",
    fontSize: "16px",
    cursor: "pointer",
  },
  errorText: {
    color: "red",
    fontSize: "14px",
    marginTop: "10px",
  },
};

export default function AdminLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const baseUrl = import.meta.env.VITE_API_BASE_URL;
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await axios.post(`${baseUrl}/auth`, {
        email,
        password
      });

      const token = response.data.data;
      const decoded = jwtDecode(token); // Extraer datos del token

      localStorage.setItem("token", token);
      localStorage.setItem("role", decoded.role); // Guardar el rol real

      toast.success("Sesión iniciada correctamente");

      // Redirigir según el rol
      if (decoded.role === "ADMIN") {
        navigate("/admin/admin-home");
      } else if (decoded.role === "RESIDENT") {
        navigate("/resident/resident-home");
      } else {
        navigate("/unauthorized");
      }

    } catch (err) {
      toast.error("Datos de inicio de sesión incorrectos");

      if (err.response?.data?.message) {
        setError(err.response.data.message);
      } else {
        setError("Usuario o contraseña incorrectos");
      }
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h1 style={styles.logo}>SCSVF</h1>
        <button style={styles.adminButton} onClick={() => navigate("/scsvf/resident")}>Soy Residente</button>
      </div>

      <div style={styles.loginBox}>
        <div style={styles.icon}>
          <img src={userIcon} alt="User Icon" style={styles.iconImg} />
        </div>

        <h1 style={styles.titulo}>SCSVF</h1>

        <input
          type="text"
          placeholder="Usuario"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={styles.inputCode}
        />

        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={styles.inputCode}
        />

        <button style={styles.submitButton} onClick={handleLogin}>
          Ingresar
        </button>

        {error && <p style={styles.errorText}>{error}</p>}
      </div>

      <ToastContainer
        position="bottom-right"
        autoClose={3000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
}

import React from "react";
import { Routes, Route } from "react-router-dom";
import AdminLogin from "../AdminLogin";
import AdminHome from "../AdminHome";
import AdminGestionGuardia from "../AdminGestionGuardia";
import AdminRegistroGuardia from "../AdminRegistroGuardia";
import AdminProfile from "../AdminProfile";
import AdminGestionResidentes from "../AdminGestionResidentes";
import AdminRegistroResidente from "../AdminRegistroResidente";
import AdminGestionCasas from "../AdminGestionCasas";
import AdminRegistroCasas from "../AdminRegistroCasas";
import AdminGestionVisitas from "../AdminGestionVisitas";
import Unauthorized from "../../Unauthorized";
import ProtectedRoute from "../../../components/PrivateRoute";
import NotFound from "../../NotFound";
import AdminGestionReportes from "../AdminGestionReportes";

const AdminRoutes = () => {
  return (
    <Routes>
      <Route path="/admin-home" element={<AdminHome />} />
      <Route path="/guardias" element={<AdminGestionGuardia />} />
      <Route path="/guardias/registro" element={<AdminRegistroGuardia />} />
      <Route path="/profile" element={<AdminProfile />} />
      <Route path="/residentes" element={<AdminGestionResidentes />} />
      <Route path="/residentes/registro" element={<AdminRegistroResidente />} />
      <Route path="/casas" element={<AdminGestionCasas />} />
      <Route path="/casas/registro" element={<AdminRegistroCasas />} />
      <Route path="/visitas" element={<AdminGestionVisitas />} />
      <Route path="/unauthorized" element={<Unauthorized />} />
      <Route path="reportes" element={<AdminGestionReportes/>}/>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};
export default AdminRoutes;
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Banner from "../../components/Header"; // Ajusta esta ruta si es diferente
import { ImTextColor } from "react-icons/im";
import editar from "../../assets/editar.png";
import Sidebar from "../../components/SidebarAdmin";
import Home from "../../assets/home.png";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const AdminGestionCasas = () => {
  const navigate = useNavigate();

  const [casas, setCasas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedCasa, setSelectedCasa] = useState(null);
  const [casaSeleccionada, setCasaSeleccionada] = useState(null);
  const baseUrl = import.meta.env.VITE_API_BASE_URL;

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  const fetchCasas = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        window.location.href = "/login";
        return;
      }

      const response = await axios.get(`${baseUrl}/api/casas`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.data && Array.isArray(response.data.data)) {
        setCasas(response.data.data);
      } else {
        toast.error("La propiedad 'data' no contiene un arreglo válido:", response.data);
        setCasas([]);
      }
    } catch (error) {
      toast.error("Error al obtener casas:", error);
      setCasas([]);
    } finally {
      setLoading(false);
    }
  };


  const handleUpdateCasa = async (e) => {
    e.preventDefault();

    const direccion = e.target.direccion.value.trim();
    const calle = e.target.calle.value.trim();
    const numeroCasa = e.target.numeroCasa.value.trim();
    const descripcion = e.target.descripcion.value.trim();
    const estado = e.target.estado.value;

    if (!direccion || !calle || !numeroCasa || !descripcion || !estado) {
      toast.warning("Por favor completa todos los campos antes de guardar.");
      return;
    }

    const formData = new FormData();
    formData.append("direccion", direccion);
    formData.append("calle", calle);
    formData.append("numeroCasa", numeroCasa);
    formData.append("descripcion", descripcion);
    formData.append("estado", estado);

    const fotoInput = e.target.foto;
    if (fotoInput.files && fotoInput.files.length > 0) {
      formData.append("foto", fotoInput.files[0]);
    }

    try {
      const token = localStorage.getItem("token");

      await axios.put(`${baseUrl}/api/casas/${selectedCasa.id}`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      toast.success("Casa actualizada exitosamente");
      setShowEditModal(false);
      fetchCasas();
    } catch (error) {
      toast.error("Hubo un error al actualizar la casa");
    }
  };


  useEffect(() => {
    fetchCasas();
  }, []);

  const styles = {
    container: {
      position: "relative", // o simplemente no pongas position
      width: "100%",
      minHeight: "100vh",
      backgroundColor: "#F09560",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "sans-serif",
      left:7,
      top: 5
      
    }, 
    titleContainer: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      position: "relative",
      width: "100%",
      maxWidth: "80%",
      marginBottom: 20,
      marginTop: 0
    },
    subtitle: {
      fontSize: 64,
      fontWeight: "bold",
      flexGrow: 1,
      textAlign: "center",
      color: "#000",
      margin: 0,
      marginTop: 0,
      marginBottom: -60
    },
    tableContainer: {
      display: "flex",
      justifyContent: "center",
      width: "100%",
      maxWidth: "80%",
      backgroundColor: "#EBEBF2",
      padding: 0,
      borderRadius: 10,
      boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.2)",
    },
    table: {
      width: "100%",
      borderCollapse: "collapse",
    },
    tableCell: {
      padding: 10,
      border: "1px solid #591202",
      textAlign: "center",
      color: "#000",
      justifyContent: "center",
    },
    tableHeader: {
      backgroundColor: '#BF8969',
      color: 'black',
      textAlign: 'center'
    },
    editButton: {
      display: 'flex',
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      backgroundColor: "#591202",
      color: "white",
      borderRadius: 5,
      cursor: "pointer",
      width: 100,
      height: 50,
    },
    modalOverlay: {
      position: "fixed",
      top: 0,
      left: 0,
      width: "100vw",
      height: "100vh",
      backgroundColor: "rgba(0, 0, 0, 0.5)",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      zIndex: 9999,
    },
    modalContent: {
      backgroundColor: "#fff",
      padding: 30,
      borderRadius: 20,
      width: "400px",
      maxWidth: "90%",
      maxHeight: "90vh",
      display: "flex",
      flexDirection: "column",
      gap: 15,
      boxShadow: "0 5px 15px rgba(0, 0, 0, 0.3)",
      overflowY: "auto", 
      scrollbarWidth: "none", // Firefox
      msOverflowStyle: "none", // IE/Edge
    },
    modalInput: {
      padding: "10px",
      fontSize: "16px",
      borderRadius: "10px",
      border: "1px solid #ccc",
      color: 'black',
      borderColor: 'black',
      backgroundColor: 'white',
      margin: 5
    },
    modalButtons: {
      display: "flex",
      justifyContent: "space-between",
      marginTop: 10,
    },
    modalButtonSave: {
      padding: "10px 20px",
      backgroundColor: "#591202",
      color: "white",
      border: "none",
      borderRadius: "999px",
      cursor: "pointer",
      fontWeight: "bold",
    },
    modalButtonCancel: {
      padding: "10px 20px",
      backgroundColor: "#ccc",
      color: "black",
      border: "none",
      borderRadius: "999px",
      cursor: "pointer",
      fontWeight: "bold",
    },
    modalLabel: {
      fontWeight: "bold",
      marginBottom: 5,
      color: "black",
    },
    ModalTitle: {
      color: "black"
    },
    ModalSub: {
      fontWeight: 'bold',
      color: "black",
      margin: 10
    },
    buttonIcon: {
      width: 25,
      height: 25
    },
    addHouse: {
      width: 30,
      height: 30
    },
    createHouse: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '10px 20px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer',
      fontWeight: 'bold',
      fontSize: 16,
      boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
      transition: '0.3s ease',
      whiteSpace: 'nowrap',
      marginTop: 200
    },
    ModalLabel: {
      color: 'black',
      fontWeight: 'Bold',
      marginRight: 10
    },

    inputModal: {
      width: '40%',
      marginBottom: 10,
      borderColor: 'black',
      backgroundColor: 'white',
      color: 'black',
      borderRadius: 5
    },
    inputModalShort: {
      width: '8%',
      marginBottom: 10,
      borderColor: 'black',
      backgroundColor: 'white',
      color: 'black',
      borderRadius: 5,
      justifyContent: 'center',
      alignItems: 'center',
      textAlign: 'center  '
    },
    inputModalMedium: {
      width: '40%',
      height: 40,
      marginBottom: 10,
      borderColor: 'black',
      backgroundColor: 'white',
      color: 'black',
      borderRadius: 8
    },
    goBackButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '10px 20px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer',
      fontWeight: 'bold',
      fontSize: 16,
      boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
      transition: '0.3s ease',
      whiteSpace: 'nowrap',
      marginTop: 200
    }

  };

  return (
    <div style={styles.container}>
      <Sidebar />
      <Banner onLogout={handleLogout} />

      <div style={styles.titleContainer}>
        <button style={styles.goBackButton} className="register-button"
          onClick={() => navigate("/admin/admin-home")}>
          Atrás
        </button>

        <h1 style={styles.subtitle} className="register-button">Casas</h1>
        <button style={styles.createHouse} onClick={() => navigate("/admin/casas/registro")}>
          Crear hogar
          <img style={styles.addHouse} src={Home} />
        </button>
      </div>

      <div style={styles.tableContainer}>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Id</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Descripcion</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Calle</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Número</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Dirección</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Foto</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Estado</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="7" style={styles.tableCell}>Cargando...</td>
              </tr>
            ) : (
              casas.map((casa) => (
                <tr key={casa.id}>
                  <td style={styles.tableCell}>{casa.id}</td>
                  <td style={styles.tableCell}>{casa.descripcion}</td>
                  <td style={styles.tableCell}>{casa.calle}</td>
                  <td style={styles.tableCell}>{casa.numeroCasa}</td>
                  <td style={styles.tableCell}>{casa.direccion}</td>

                  <td style={styles.tableCell}>
                    {casa.foto ? (
                      <img
                        src={`data:image/jpeg;base64,${casa.foto}`}
                        alt="Foto casa"
                        style={{
                          width: 80,
                          height: 60,
                          objectFit: "cover",
                          borderRadius: 8,
                          border: "1px solid #ccc"
                        }}
                      />
                    ) : (
                      "Sin foto"
                    )}
                  </td>
                  <td style={{
                    ...styles.tableCell,
                    color: casa.estado === "Activa" ? "green" : "red",
                    fontWeight: "bold"
                  }}>
                    {casa.estado}
                  </td>
                  <td style={styles.tableCell}>
                    <button
                      style={styles.editButton}
                      onClick={() => {
                        setSelectedCasa(casa);
                        setCasaSeleccionada({ ...casa }); // ← esto es lo que faltaba
                        setShowEditModal(true);
                      }}>
                      <img src={editar} alt="Editar" style={styles.buttonIcon} />
                      Editar
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showEditModal && selectedCasa && (
        <div style={styles.modalOverlay}>
          <div style={styles.modalContent}>
            <h2 style={styles.ModalTitle}>Editar Casa</h2>
            <form onSubmit={handleUpdateCasa}>

              {selectedCasa.foto && (
                <img
                  src={`data:image/jpeg;base64,${selectedCasa.foto}`}
                  alt="Foto actual de la casa"
                  style={{
                    width: "100%",
                    height: "auto",
                    maxHeight: 200,
                    objectFit: "cover",
                    borderRadius: 12,
                    marginBottom: 10,
                    border: "1px solid #ccc",
                  }}
                />
              )}

              <br />
              <div style={{ display: "flex", flexDirection: "column", marginBottom: 5, color: 'black', fontWeight: 'bold' }}>
                <label htmlFor="direccion" style={styles.modalLabel}>Descripción<noframes></noframes>: </label>
                <input
                  type="text"
                  name="descripcion"
                  defaultValue={selectedCasa.descripcion}
                  style={styles.modalInput}
                  placeholder="Descripción"
                />
              </div>
              <div style={{ display: "flex", flexDirection: "column", marginBottom: 10, color: 'black', fontWeight: 'bold' }}>
                <label htmlFor="direccion" style={styles.modalLabel}>Dirección: </label>
                <input
                  type="text"
                  name="direccion"
                  id="direccion"
                  defaultValue={selectedCasa.direccion}
                  style={styles.modalInput}
                />
              </div>
              <div style={{ display: "flex", flexDirection: "column", marginBottom: 5, color: 'black', fontWeight: 'bold' }}>
                <label htmlFor="direccion" style={styles.modalLabel}>Calle: </label>
                <input
                  type="text"
                  name="calle"
                  defaultValue={selectedCasa.calle}
                  style={styles.modalInput}
                  placeholder="Calle"
                />
              </div>

              <div style={{ display: "flex", flexDirection: "column", marginBottom: 5, color: 'black', fontWeight: 'bold' }}>
                <label htmlFor="direccion" style={styles.modalLabel}>Numero: </label>
                <input
                  type="text"
                  name="numeroCasa"
                  defaultValue={selectedCasa.numeroCasa}
                  style={styles.modalInput}
                  placeholder="Número de casa"
                />
              </div>

              <label style={styles.ModalLabel} >Estado:</label>
              <br />
              <select
                name="estado"
                value={casaSeleccionada.estado}
                onChange={(e) =>
                  setCasaSeleccionada({
                    ...casaSeleccionada,
                    estado: e.target.value,
                  })
                }
                style={styles.inputModalMedium}
              >
                <option value="Activa">Activa</option>
                <option value="Inactiva">Inactiva</option>
              </select>

              <div style={{ display: "flex", flexDirection: "column", marginBottom: 5, color: 'black', fontWeight: 'bold' }}>
                <label htmlFor="direccion" style={styles.modalLabel}>Foto: </label>
                <input
                  type="file"
                  name="foto"
                  accept="image/*"
                  style={styles.modalInput}
                />
              </div>


              <div style={styles.modalButtons}>
                <button type="submit" style={styles.modalButtonSave}>
                  Guardar
                </button>
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  style={styles.modalButtonCancel}
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      <ToastContainer
        position="bottom-right"
        autoClose={3000} // tiempo en ms que el toast permanece visible
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );
};

export default AdminGestionCasas;

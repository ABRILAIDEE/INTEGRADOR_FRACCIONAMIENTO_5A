import { useState, useEffect } from "react";
import profileIcon from "../../assets/policemen.png";
import Banner from "../../components/Header";
import { useNavigate } from "react-router-dom";
import Sidebar from "../../components/SidebarAdmin";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";

const styles = {
  container: {
    position: "relative", // o simplemente no pongas position
    width: "100%",
    minHeight: "112vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "sans-serif",
    left:7,
    top: 5
  },
  logo: {
    fontWeight: "bold",
    fontSize: "25px",
    color: "black",
    margin: 0,
  },
  logoutButton: {
    backgroundColor: "#4A1004",
    color: "white",
    padding: "8px 16px",
    border: "none",
    borderRadius: "999px",
    fontSize: "14px",
    fontWeight: "bold",
    height: "40px",
    cursor: "pointer",
  },
  logoutContainer: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  logoutIcon: {
    width: "36px",
    height: "36px",
    cursor: "pointer",
    transition: "transform 0.2s",
  },
  logoutIconHover: {
    transform: "scale(1.1)",
  },
  title: {
    fontSize: '21px',
    fontWeight: 'bold',
    color: '#000',
  },
  profileSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  titleContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    width: '100%',
    maxWidth: '80%',
    margin: '30px auto',
    marginTop: '10px',
  },
  subtitle: {
    fontSize: '64px',
    fontWeight: 'bold',
    flexGrow: '1',
    textAlign: 'center',
    color: '#000',
    margin: '0',
  },
  buttonContainer: {
    display: 'flex',
    gap: '10px',
    position: 'absolute',
    right: 0,
  },
  bloquearButton: {
    backgroundColor: 'red',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: 'bold',
    marginLeft: '-490px',
  },
  desbloquearButton: {
    backgroundColor: 'green',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: 'bold',
  },
  formContainer: {
    display: 'flex',
    flexDirection: 'row',
    gap: '40px',
    alignItems: 'center',
    justifyContent: 'center',
    width: '80%',
    position: 'relative',
  },
  profileIcon: {
    fontSize: '100px',
    backgroundColor: '#f0f0f0',
    width: '400px',
    height: '400px',
    borderRadius: '50%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: '-230px',
    flexShrink: 0,
    overflow: 'hidden',
  },
  profileIconImage: {
    width: '90%',
    height: '90%',
    objectFit: 'cover',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    marginTop: '15px',
  },
  formGroup: {
    textAlign: 'left',
  },
  label: {
    fontWeight: 'bold',
    display: 'block',
    marginBottom: '5px',
    color: '#000',
  },
  input: {
    width: '180%',
    height: '20px',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    color: '#000',
    backgroundColor: '#EBEBF2',
    fontSize: '16px',
  },

  dateInput: {
    width: '180%',
    height: '20px',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    color: "white",
    backgroundColor: '#591202',
    fontSize: '16px',
  },
  submitButtonContainer: {
    display: 'flex',
    justifyContent: 'center',
    marginTop: '20px',
  },
  editButton: {
    backgroundColor: '#591202',
    color: 'white',
    padding: '10px',
    border: 'none',
    height: '5%',
    width: '200%',
    borderRadius: '30px',
    fontSize: '20px',
    cursor: 'pointer',
    marginTop: '15px',
    marginLeft: '-200px',
    alignSelf: 'center',
    fontWeight: 'bold'
  },
  editButtonHover: {
    backgroundColor: '#3d1f0e',
  },
};

export default function AdminProfile() {
  const baseUrl = import.meta.env.VITE_API_BASE_URL;

  const [form, setForm] = useState({
    nombre: "",
    apellidos: "",
    edad: "",
    fechaNacimiento: "",
    direccion: "",
    calle: "",
    telefono: "",
  });
  const [isEditing, setIsEditing] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem("token");

      try {
        const response = await axios.get(`${baseUrl}/api/empleados/me`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const result = response.data;

        if (result && result.data) {
          const { nombre, apellidos, edad, fechaNacimiento, direccion, calle, telefono } = result.data;
          setForm({ nombre, apellidos, edad, fechaNacimiento, direccion, calle, telefono });
        } else {
          toast.error("Error al obtener perfil: " + result.message);
        }
      } catch (error) {
        toast.error("Error al conectar con el servidor: " + error.message);
      }
    };

    fetchProfile();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    if (!isEditing) {
      setIsEditing(true);
      return;
    }
  
    for (const key in form) {
      if (!form[key] || form[key].toString().trim() === "") {
        toast.error("Todos los campos deben estar completos.");
        return;
      }
    }
  
    const token = localStorage.getItem("token");
  
    try {
      const response = await axios.put(`${baseUrl}/api/empleados/me`, form, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
  
      const data = response.data;
  
      if (data) {
        toast.success("Perfil actualizado correctamente");
        setIsEditing(false);
      } else {
        toast.error("Error al actualizar el perfil");
      }
    } catch (error) {
      toast.error("Error al conectar con el servidor: " + error.message);
    }
  };


  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div style={styles.container}>
      <Sidebar />
      <Banner onLogout={handleLogout} />

      <div style={styles.titleContainer}>
        <h1 style={styles.subtitle}>Tu perfil</h1>
      </div>

      <div style={styles.formContainer}>
        <div style={styles.profileIcon}>
          <img src={profileIcon} alt="Profile" style={styles.profileIconImage} />
        </div>
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Nombre:</label>
            <input
              type="text"
              name="nombre"
              placeholder="Ingresa su nombre"
              value={form.nombre}
              onChange={handleChange}
              style={styles.input}
              readOnly={!isEditing}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Apellidos:</label>
            <input
              type="text"
              name="apellidos"
              placeholder="Ingrese sus apellidos"
              value={form.apellidos}
              onChange={handleChange}
              style={styles.input}
              readOnly={!isEditing}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Edad:</label>
            <input
              type="number"
              name="edad"
              placeholder="Ingrese su edad"
              value={form.edad}
              onChange={handleChange}
              style={styles.input}
              readOnly={!isEditing} />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Fecha de nacimiento:</label>
            <input
              type="date"
              name="fechaNacimiento"
              placeholder="Ingrese fecha de nacimiento"
              value={form.fechaNacimiento}
              onChange={handleChange}
              style={styles.dateInput}
              readOnly={!isEditing} />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Dirección:</label>
            <input
              type="text"
              name="direccion"
              placeholder="Ingrese su dirección"
              value={form.direccion}
              onChange={handleChange}
              style={styles.input}
              readOnly={!isEditing} />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Calle:</label>
            <input
              type="text"
              name="calle"
              value={form.calle}
              onChange={handleChange}
              style={styles.input}
              readOnly={!isEditing}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Teléfono:</label>
            <input
              type="tel"
              name="telefono"
              placeholder="Ingrese su número telefónico"
              value={form.telefono}
              onChange={handleChange}
              style={styles.input}
              readOnly={!isEditing} />
          </div>
          <div style={styles.submitButtonContainer}>
            <button type="submit" style={styles.editButton}>
              {isEditing ? "Guardar cambios" : "Editar información"}
            </button>
          </div>
        </form>
      </div>
      <ToastContainer
        position="bottom-right"
        autoClose={3000} // tiempo en ms que el toast permanece visible
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );
}
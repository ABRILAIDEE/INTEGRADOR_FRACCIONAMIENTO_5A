import React, { useState } from "react";
import usuario from "../../assets/home.png";
import Banner from "../../components/Header";
import { useNavigate } from "react-router-dom";
import Sidebar from "../../components/SidebarAdmin";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const styles = {
  container: {
    position: "relative", // o simplemente no pongas position
    width: "100%",
    minHeight: "112vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "sans-serif",
    left:7,
    top: 5
  },
  logout: {
    backgroundColor: '#591202',
    borderRadius: 35,
    border: 'none',
    cursor: 'pointer',
    color: '#fff',
    padding: '8px 16px'
  },

  logo: {
    fontWeight: "bold",
    fontSize: "25px",
    color: "black",
    margin: 0,
  },
  logoutButton: {
    backgroundColor: "#4A1004",
    color: "white",
    padding: "8px 16px",
    border: "none",
    borderRadius: "999px",
    fontSize: "14px",
    fontWeight: "bold",
    height: "40px",
    cursor: "pointer",
  },
  logoutContainer: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  logoutIcon: {
    width: "36px",
    height: "36px",
    cursor: "pointer",
    transition: "transform 0.2s",
  },
  logoutIconHover: {
    transform: "scale(1.1)",
  },
  title: {
    fontSize: '21px',
    fontWeight: 'bold',
    color: '#000',
  },
  profileSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  titleContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    width: '100%',
    maxWidth: '80%',
    marginTop: 0,
    marginBottom: 50,
    marginRight: 300
  },
  subtitle: {
    fontSize: '64px',
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#000',
  },
  formContainer: {
    display: 'flex',
    flexDirection: 'row',
    gap: '40px',
    alignItems: 'center',
    justifyContent: 'center',
    width: '80%',
    position: 'relative',
    marginTop: "-40px"
  },
  profileIcon: {
    backgroundColor: '#f0f0f0',
    width: '400px',
    height: '400px',
    borderRadius: '20%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    margin: 'auto 0',
    marginLeft: '-300px',
    overflow: 'hidden',
  },
  profileImage: {
    width: '90%',
    height: '90%',
    objectFit: 'cover',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    marginTop: '15px',
  },
  formGroup: {
    textAlign: 'left',
    width: '100%',
  },
  label: {
    fontWeight: 'bold',
    display: 'block',
    marginBottom: '5px',
    color: '#000',
  },
  inputField: {
    width: '90%',
    height: '20px',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    color: '#000',
    backgroundColor: '#EBEBF2',
    fontSize: '16px',
  },
  mediumInputField: {
    width: '20%',
    height: '20px',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    color: '#000',
    backgroundColor: '#EBEBF2',
    fontSize: '16px',
  },
  textField: {
    width: '150%',
    height: '100px',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    color: '#000',
    backgroundColor: '#EBEBF2',
    fontSize: '16px',
    resize: 'none'
  },
  submitButtonContainer: {
    display: 'flex',
    justifyContent: 'center',
    marginTop: '20px',
  },
  submitButton: {
    backgroundColor: '#591202',
    color: 'white',
    padding: '10px',
    border: 'none',
    height: '5%',
    width: '200%',
    borderRadius: '30px',
    fontSize: '20px',
    cursor: 'pointer',
    marginTop: '15px',
    marginLeft: '-200px',
    alignSelf: 'center',
  },
  submitButtonHover: {
    backgroundColor: '#3d1f0e',
  },
  goBackButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#591202',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: 35,
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: 16,
    boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
    transition: '0.3s ease',
    whiteSpace: 'nowrap',
    marginRight: 250
  }
};

export default function AdminRegistroCasas() {
  const [form, setForm] = useState({
    direccion: "",
    calle: "",
    numeroCasa: "",
    descripcion: "",
    foto: null,
  });


  const navigate = useNavigate();
  const baseUrl = import.meta.env.VITE_API_BASE_URL;
  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "foto") {
      setForm({ ...form, foto: files[0] });
    } else {
      setForm({ ...form, [name]: value });
    }
  };


  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("direccion", form.direccion);
    formData.append("calle", form.calle);
    formData.append("numeroCasa", form.numeroCasa);
    formData.append("descripcion", form.descripcion);
    formData.append("estado", "Activa");
    formData.append("foto", form.foto); // Puede ser null si no se sube

    try {
      const token = localStorage.getItem("token");

      const response = await axios.post(`${baseUrl}/api/casas`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      });

      toast.success("Casa registrada exitosamente.");
      setForm({
        direccion: "",
        calle: "",
        numeroCasa: "",
        descripcion: "",
        foto: null,
      });
    } catch (error) {
      toast.warning("Porfavor, llena todos los campos antes de registrar una casa");
    }
  };


  return (
    <div style={styles.container}>
      <Sidebar />
      <Banner onLogout={handleLogout} />
      <div style={styles.titleContainer}>
        <button style={styles.goBackButton} className="register-button"
          onClick={() => navigate("/admin/casas")}>
          Atrás
        </button>
        <h1 style={styles.subtitle}>Registro de casas</h1>
      </div>

      <div style={styles.formContainer}>
        <div style={styles.profileIcon}>
          <img src={usuario} alt="Profile" style={styles.profileImage} />
        </div>
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Calle:</label>
            <input
              type="text"
              name="calle"
              placeholder="Ingresa la calle"
              value={form.calle}
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Numero de casa:</label>
            <input
              type="number"
              name="numeroCasa"
              placeholder="Número de casa"
              value={form.numeroCasa}
              onChange={handleChange}
              style={styles.mediumInputField}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Foto:</label>
            <input
              type="file"
              name="foto"
              placeholder="Sube la foto de la nueva casa"
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>
          {form.foto && (
            <img
              src={URL.createObjectURL(form.foto)}
              alt="Vista previa"
              style={{ width: 200, height: 200, borderRadius: 10, marginTop: 10 }}
            />
          )}
          <div style={styles.formGroup}>
            <label style={styles.label}>Direccion:</label>
            <input
              type="text"
              name="direccion"
              placeholder="Ingresa la dirección"
              value={form.direccion}
              onChange={handleChange}
              style={styles.inputField}
            />

          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Descripcion:</label>
            <textarea
              name="descripcion"
              placeholder="Describe el nuevo hogar"
              value={form.descripcion}
              onChange={handleChange}
              style={styles.textField}
            />
          </div>
          <div style={styles.submitButtonContainer}>
            <button type="submit" style={styles.submitButton}>
              Registrar casa
            </button>
          </div>
        </form>
      </div>
      <ToastContainer
        position="bottom-right"
        autoClose={3000} // tiempo en ms que el toast permanece visible
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );
}

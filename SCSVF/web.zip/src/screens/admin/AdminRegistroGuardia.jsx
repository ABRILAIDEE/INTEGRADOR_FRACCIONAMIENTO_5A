import React, { useState } from "react";
import usuario from "../../assets/policemen.png";
import Banner from "../../components/Header";
import { useNavigate } from "react-router-dom";
import Sidebar from "../../components/SidebarAdmin";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";

const styles = {
  container: {
    position: "relative", // o simplemente no pongas position
    width: "100%",
    minHeight: "112vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "sans-serif",
    left:7,
    top: 5
  },
  logout: {
    backgroundColor: '#591202',
    borderRadius: 35,
    border: 'none',
    cursor: 'pointer',
    color: '#fff',
    padding: '8px 16px'
  },
  logo: {
    fontWeight: "bold",
    fontSize: "25px",
    color: "black",
    margin: 0,
  },
  logoutIconHover: {
    transform: "scale(1.1)",
  },
  title: {
    fontSize: '21px',
    fontWeight: 'bold',
    color: '#000',
  },
  profileSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  titleContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    maxWidth: '80%',
    margin: '40px 0',
    flexWrap: 'wrap',
    gap: 20
  },
  subtitle: {
    fontSize: 48,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#000',
    flex: 1
  },
  
  formContainer: {
    display: 'flex',
    flexDirection: 'row',
    gap: '40px',
    alignItems: 'center',
    justifyContent: 'center',
    width: '80%',
    position: 'relative',
    marginTop: "-40px"
  },
  profileIcon: {
    backgroundColor: '#f0f0f0',
    width: '400px',
    height: '400px',
    borderRadius: '50%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    margin: 'auto 0',
    marginLeft: '-300px',
    overflow: 'hidden', // Asegura que la imagen no se desborde
  },
  profileImage: {
    width: '90%',
    height: '90%',
    objectFit: 'cover', // Mantiene la imagen dentro del círculo
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    marginTop: '15px',
  },
  formGroup: {
    textAlign: 'left',
    width: '100%',
  },
  label: {
    fontWeight: 'bold',
    display: 'block',
    marginBottom: '5px',
    color: '#000',
  },
  inputField: {
    width: '250%',
    height: '20px',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    color: '#000',
    backgroundColor: '#EBEBF2',
    fontSize: '16px',
  },
  submitButtonContainer: {
    display: 'flex',
    justifyContent: 'center',
    marginTop: '20px',
  },
  submitButton: {
    backgroundColor: '#591202',
    color: 'white',
    padding: '10px',
    border: 'none',
    height: '5%',
    width: '200%',
    borderRadius: '30px',
    fontSize: '20px',
    cursor: 'pointer',
    marginTop: '15px',
    marginLeft: '-200px',
    alignSelf: 'center',
  },
  submitButtonHover: {
    backgroundColor: '#3d1f0e',
  },
  goBackButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#591202',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: 35,
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: 16,
    boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
    transition: '0.3s ease',
    whiteSpace: 'nowrap',
    marginRight: 150
  }

};

export default function AdminRegistroGuardia() {
  const [form, setForm] = useState({
    nombre: "",
    apellidos: "",
    edad: "",
    fechaNacimiento: "",
    email: "",
    telefono: "",
    direccion: "",
    calle: "",
    contrasena: ""
  });

  const navigate = useNavigate();

  const baseUrl = import.meta.env.VITE_API_BASE_URL;

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
  
    const camposIncompletos = Object.values(form).some(value => value.trim() === "");
    if (camposIncompletos) {
      toast.warning("Por favor, completa todos los campos antes de registrar al guardia.");
      return;
    }
  
    const token = localStorage.getItem("token");
  
    const payload = {
      ...form,
      estado: "Activo",
      rol: {
        id: 2
      }
    };
  
    try {
      const response = await axios.post(`${baseUrl}/api/empleados`, payload, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        }
      });
  
      toast.success("Guardia creado exitosamente");
      setForm({
        nombre: "",
        apellidos: "",
        edad: "",
        fechaNacimiento: "",
        email: "",
        telefono: "",
        direccion: "",
        calle: "",
        contrasena: ""
      });
    } catch (error) {
      console.error("Error al registrar guardia:", error);
      toast.error("Ocurrió un error al registrar el guardia.");
    }
  };  

  return (
    <div style={styles.container}>
      <Sidebar />
      <Banner onLogout={handleLogout} />
      <div style={styles.titleContainer}>
        <button style={styles.goBackButton} className="register-button"
          onClick={() => navigate("/admin/guardias")}>
          Atrás
        </button>
        <h1 style={styles.subtitle}>Registro de guardia</h1>
      </div>

      <div style={styles.formContainer}>
        <div style={styles.profileIcon}>
          <img src={usuario} alt="Profile" style={styles.profileImage} />
        </div>
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Nombre:</label>
            <input
              type="text"
              name="nombre"
              placeholder="Ingresa el nombre"
              value={form.nombre}
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Apellidos:</label>
            <input
              type="text"
              name="apellidos"
              placeholder="Ingresa los apellidos"
              value={form.apellidos}
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Correo electrónico:</label>
            <input
              type="email"
              name="email"
              placeholder="Ingresa el correo"
              value={form.email}
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Edad:</label>
            <input
              type="number"
              name="edad"
              placeholder="Ingresa la edad"
              value={form.edad}
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Fecha de nacimiento:</label>
            <input
              type="date"
              name="fechaNacimiento"
              placeholder="Ingresa la fecha de nacimiento"
              value={form.fechaNacimiento}
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Dirección:</label>
            <input
              type="text"
              name="direccion"
              placeholder="Ingresa la dirección"
              value={form.direccion}
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Teléfono:</label>
            <input
              type="text"
              name="telefono"
              placeholder="Ingresa el teléfono"
              value={form.telefono}
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Calle:</label>
            <input
              type="text"
              name="calle"
              placeholder="Ingresa la calle"
              value={form.calle}
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Contraseña:</label>
            <input
              type="password"
              name="contrasena"
              placeholder="Ingresa la contraseña"
              value={form.contrasena}
              onChange={handleChange}
              style={styles.inputField}
            />
          </div>

          <div style={styles.submitButtonContainer}>
            <button type="submit" style={styles.submitButton}>
              Registrar guardia
            </button>
          </div>
        </form>
      </div>
      <ToastContainer
        position="bottom-right"
        autoClose={3000} // tiempo en ms que el toast permanece visible
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />

    </div>
  );
}

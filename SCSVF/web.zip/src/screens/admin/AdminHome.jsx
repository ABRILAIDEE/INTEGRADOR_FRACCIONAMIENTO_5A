import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Banner from "../../components/Header";
import guard from "../../assets/policemen.png";
import group from "../../assets/multiple-users-silhouette.png";
import map from "../../assets/map.png";
import home from "../../assets/home.png";
import Sidebar from "../../components/SidebarAdmin.jsx";
import axios from "axios";

const styles = {
  container: {
    width: "100%",
    minHeight: "100vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "fixed",
    fontFamily: "sans-serif",
    left: 0,
    top:0
  },
  logo: {
    fontWeight: "bold",
    fontSize: "25px",
    color: "black",
    margin: 0,
  },
  logoutButton: {
    backgroundColor: "#4A1004",
    color: "white",
    padding: "8px 16px",
    border: "none",
    borderRadius: "999px",
    fontSize: "14px",
    fontWeight: "bold",
    height: "40px",
    cursor: "pointer",
  },
  logoutContainer: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  logoutIcon: {
    width: "36px",
    height: "36px",
    cursor: "pointer",
    transition: "transform 0.2s",
  },
  logoutIconHover: {
    transform: "scale(1.1)",
  },
  loginBox: {
    marginTop: "60px",
    textAlign: "center",
  },
  icon: {
    marginBottom: "60px",
  },
  iconImg: {
    width: "200px",
    height: "200px",
    marginBottom: "-40px",
    objectFit: "contain",
  },
  titleHome: {
    color: "#000",
  },
  createVisitButton: {
    display: "block",
    margin: "0 auto",
    backgroundColor: "#EBEBF2",
    color: "#000",
    padding: "12px 20px",
    width: "500px",
    height: "40px",
    border: "none",
    borderRadius: "999px",
    fontSize: "20px",
    cursor: "pointer",
    marginBottom: "20px",
    fontWeight: "bold",
  },
  myVisitsButton: {
    display: "block",
    margin: "0 auto",
    backgroundColor: "#EBEBF2",
    color: "#000",
    padding: "12px 20px",
    width: "500px",
    height: "40px",
    border: "none",
    borderRadius: "999px",
    fontSize: "20px",
    cursor: "pointer",
    fontWeight: "bold",
    marginBottom: "20px",
  },
  smallIcon:{
    height:20,
    width: 20,
    marginRight:15,
  }
};


//COMPONENTE
const AdminHome = () => {

  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };
  

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/"); // redirige al login si no hay token
    }
  }, [navigate]);

  const token = localStorage.getItem("token");

  return (
    
    <div style={styles.container}>
      <Sidebar  />
      <Banner onLogout={handleLogout} />
      <div style={styles.loginBox}>
        <h1 style={styles.titleHome}>¿Qué vas a hacer hoy?</h1>
          
        <button
        style={styles.createVisitButton}
        onClick={() => navigate("/admin/guardias")}
        >
        <img src={guard} style={styles.smallIcon} />
        Gestión de guardias
        </button>

        <button
        style={styles.myVisitsButton}
        onClick={() => navigate("/admin/residentes")}
        >
        <img src={group} style={styles.smallIcon} />
        Gestión de residentes
        </button>

        <button
        style={styles.myVisitsButton}
        onClick={() => navigate("/admin/casas")}
        >
        <img src={home} style={styles.smallIcon} />
        Gestión de casas
        </button>

        <button
        style={styles.myVisitsButton}
        onClick={() => navigate("/admin/visitas")}
        >
        <img src={map} style={styles.smallIcon} />
        Gestión de visitas
        </button>

      </div>
    </div>
  );
};

export default AdminHome;

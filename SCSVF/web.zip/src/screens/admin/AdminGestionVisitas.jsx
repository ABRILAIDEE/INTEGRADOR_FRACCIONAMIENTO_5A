import React, { useEffect, useState } from "react";
import editar from "../../assets/editar.png";
import profileIcon from "../../assets/usuario.png";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Banner from "../../components/Header";
import Sidebar from "../../components/SidebarAdmin";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axiosInstance from "../../api/axiosInstance";

const AdminGestionVisitas = () => {
  const [visitas, setVisitas] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [visitaSeleccionada, setVisitaSeleccionada] = useState(null);
  const [nuevoStatusId, setNuevoStatusId] = useState("");
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedCasa, setSelectedCasa] = useState(null);
  const baseUrl = import.meta.env.VITE_API_BASE_URL;

  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };
  useEffect(() => {
    const fetchVisitas = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get(`${baseUrl}/api/visitas`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        setVisitas(response?.data?.data || []);
      } catch (error) {
        toast.error("Error al cargar visitas:", error);
      }
    };

    fetchVisitas();
  }, []);

  const styles = {
    container: {
      position: "relative", // o simplemente no pongas position
      width: "100%",
      minHeight: "100vh",
      backgroundColor: "#F09560",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "sans-serif",
      left: 7,
      top: 5
    },
    logo: {
      fontWeight: "bold",
      fontSize: "25px",
      color: "black",
      margin: 0,
    },
    logoutButton: {
      backgroundColor: "#4A1004",
      color: "white",
      padding: "8px 16px",
      border: "none",
      borderRadius: "999px",
      fontSize: "14px",
      fontWeight: "bold",
      height: "40px",
      cursor: "pointer",
    },
    logoutContainer: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
    },
    logoutIcon: {
      width: "36px",
      height: "36px",
      cursor: "pointer",
      transition: "transform 0.2s",
    },
    logoutIconHover: {
      transform: "scale(1.1)",
    },
    title: {
      fontSize: 21,
      fontWeight: 'bold',
      color: '#000'
    },
    profileSection: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginLeft: 'auto'
    },
    logout: {
      backgroundColor: '#591202',
      borderRadius: 35,
      border: 'none',
      cursor: 'pointer',
      color: '#fff',
      padding: '8px 16px'
    },
    profileIcon: {
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 40,
      height: 40,
      borderRadius: '50%',
      backgroundColor: '#fff',
      transition: '0.3s ease',
      overflow: 'hidden'
    },
    titleContainer: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      width: '100%',
      maxWidth: '80%',
      margin: '40px 0',
      flexWrap: 'wrap',
      gap: 20,
      marginTop: 100
    },
    subtitle: {
      fontSize: 48,
      fontWeight: 'bold',
      textAlign: 'center',
      color: '#000',
      flex: 1
    },

    buttonContainer: {
      position: 'absolute',
      right: 0
    },
    registerButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '10px 20px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer',
      fontWeight: 'bold',
      fontSize: 16,
      boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
      transition: '0.3s ease',
      whiteSpace: 'nowrap'
    },
    buttonIcon: {
      width: 25,
      height: 25
    },
    tableContainer: {
      display: 'flex',
      justifyContent: 'center',
      width: '100%',
      maxWidth: '80%',
      backgroundColor: '#EBEBF2',
      padding: 0,
      borderRadius: 10,
      boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.2)'
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse'
    },
    tableCell: {
      padding: 12,
      border: '1px solid #591202',
      textAlign: 'left',
      color: '#000'
    },
    tableHeader: {
      backgroundColor: '#BF8969',
      color: 'black',
      textAlign: 'center'
    },
    statusActive: {
      color: 'green',
      fontWeight: 'bold'
    },
    statusBlocked: {
      color: 'red',
      fontWeight: 'bold'
    },
    editButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '5px 10px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer'
    },
    modalTitle: {
      color: 'black'
    },
    goBackButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '12px 20px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer',
      fontWeight: 'bold',
      fontSize: 16,
      boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
      transition: '0.3s ease',
      whiteSpace: 'nowrap',
      marginTop: 12
    }
  };

  const getStatusStyle = (status) => {
    return status === "Terminada" ? styles.statusTerminada : styles.statusPendiente;
  };

  return (
    <div style={styles.container}>
      <Sidebar />
      <Banner onLogout={handleLogout} />

      <div style={styles.titleContainer}>
        <button style={styles.goBackButton} className="register-button"
          onClick={() => navigate("/admin/admin-home")}>
          Atrás
        </button>
        <h2 style={styles.subtitle}>Historial de Visitas</h2>
      </div>

      <div style={styles.tableContainer}>
        <table style={styles.table}>
          <thead>
            <tr style={styles.tableHeader}>
              <th style={styles.tableCell}>ID</th>
              <th style={styles.tableCell}>Visitante</th>
              <th style={styles.tableCell}>Descripción</th>
              <th style={styles.tableCell}>Placas</th>
              <th style={styles.tableCell}>Tipo</th>
              <th style={styles.tableCell}># Personas</th>
              <th style={styles.tableCell}>Fecha</th>
              <th style={styles.tableCell}>Hora</th>
              <th style={styles.tableCell}>Estatus</th>
              <th style={styles.tableCell}>Residente</th>
              <th style={styles.tableCell}>Dirección</th>
              <th style={styles.tableCell}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {visitas.map((visita) => (
              <tr key={visita.id}>
                <td style={styles.tableCell}>{visita.id}</td>
                <td style={styles.tableCell}>{visita.nombreVisitante}</td>
                <td style={styles.tableCell}>{visita.descripcion}</td>
                <td style={styles.tableCell}>{visita.placasVehiculo}</td>
                <td style={styles.tableCell}>{visita.tipoVisita}</td>
                <td style={styles.tableCell}>{visita.numeroPersonas}</td>
                <td style={styles.tableCell}>{visita.fecha}</td>
                <td style={styles.tableCell}>{visita.hora}</td>
                <td style={{ ...styles.tableCell, ...getStatusStyle(visita.status?.name) }}>
                  {visita.status?.name}
                </td>
                <td style={styles.tableCell}>
                  {visita.resident?.nombre} {visita.resident?.apellidos}
                </td>
                <td style={styles.tableCell}>
                  {visita.house?.calle} #{visita.house?.numeroCasa}
                </td>
                <td style={styles.tableCell}>
                  <button
                    style={styles.editButton}
                    onClick={() => {
                      setVisitaSeleccionada(visita);
                      setNuevoStatusId(visita.status?.id || "");
                      setShowModal(true);
                    }}
                  >
                    <img src={editar} alt="Editar" style={styles.buttonIcon} />
                    Editar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal para editar estatus */}
      {showModal && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh',
          backgroundColor: 'rgba(0, 0, 0, 0.5)', display: 'flex',
          justifyContent: 'center', alignItems: 'center'
        }}>
          <div style={{
            backgroundColor: 'white', padding: 20, borderRadius: 10,
            width: 400, display: 'flex', flexDirection: 'column', gap: 10
          }}>
            <h3 style={styles.modalTitle}>Estatus de Visita </h3>

            <select
              value={nuevoStatusId}
              onChange={(e) => setNuevoStatusId(e.target.value)}
              style={{ padding: 10, color: 'black', backgroundColor: 'white', borderRadius: 5 }}
            >
              <option value="1">Pendiente</option>
              <option value="2">En Progreso</option>
              <option value="3">Terminada</option>
              <option value="5">Cancelada</option>
            </select>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
              <button style={{ padding: '8px 16px', backgroundColor: '#591202', color: 'white', border: 'none', cursor: 'pointer', borderRadius: 8, fontWeight: 'bold' }} onClick={async () => {

                try {
                  const token = localStorage.getItem("token");

                  await axios.patch(
                    `${baseUrl}/api/visitas/updateStatus/${visitaSeleccionada.id}`,
                    { id: parseInt(nuevoStatusId) },
                    { headers: { Authorization: `Bearer ${token}` } }
                  );
                  setShowModal(false);
                  // Re-carga visitas para reflejar el cambio
                  const response = await axios.get(`${baseUrl}/api/visitas`, {
                    headers: { Authorization: `Bearer ${token}` }
                  });
                  setVisitas(response?.data?.data || []);
                  toast.success("Estatus actualizado exitosamente");
                } catch (error) {
                  toast.error("Error al actualizar estatus");
                }
              }}>
                Guardar
              </button>

              <button style={{ padding: '8px 16px', backgroundColor: '#ccc', color: 'black', border: 'none', cursor: 'pointer', borderRadius: 8, fontWeight: 'bold' }} onClick={() => setShowModal(false)} >Cancelar</button>
            </div>
          </div>
        </div>
      )}
      <ToastContainer
        position="bottom-right"
        autoClose={3000} // tiempo en ms que el toast permanece visible
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );

};

export default AdminGestionVisitas;

import React, { useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom';
import axios from "axios";
import usuario from "../../assets/usuario.png";
import Banner from "../../components/Header";
import Sidebar from "../../components/SidebarAdmin";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function AdminRegistroResidente() {
  const styles = {
    container: {
      position: "relative",
      width: "100%",
      minHeight: "112vh",
      backgroundColor: "#F09560",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "sans-serif",
      left:7,
      top: 5
    },
    logout: {
      backgroundColor: '#591202',
      borderRadius: 35,
      border: 'none',
      cursor: 'pointer',
      color: '#fff',
      padding: '8px 16px'
    },
    header: {
      position: "absolute",
      top: 0,
      left: 0,
      height: "70px",
      width: "100%",
      backgroundColor: "#f2f2f2",
      padding: "16px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      boxSizing: "border-box", // Asegúrate de que el padding no cause desbordamiento
    },
    logo: {
      fontWeight: "bold",
      fontSize: "25px",
      color: "black",
      margin: 0,
    },
    logoutButton: {
      backgroundColor: "#4A1004",
      color: "white",
      padding: "8px 16px",
      border: "none",
      borderRadius: "999px",
      fontSize: "14px",
      fontWeight: "bold",
      height: "40px",
      cursor: "pointer",
    },
    logoutContainer: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
    },
    logoutIcon: {
      width: "36px",
      height: "36px",
      cursor: "pointer",
      transition: "transform 0.2s",
    },
    logoutIconHover: {
      transform: "scale(1.1)",
    },
    title: {
      fontSize: '21px',
      fontWeight: 'bold',
      color: '#000',

    },
    profileSection: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    titleContainer: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      position: 'relative',
      width: '100%',
      maxWidth: '80%',
      marginTop: 10,
      marginBottom: 50,
      marginRight: 250
    },
    subtitle: {
      fontSize: '64px',
      fontWeight: 'bold',
      textAlign: 'center',
      color: '#000',
    },
    formContainer: {
      display: 'flex',
      flexDirection: 'row',
      gap: '40px',
      alignItems: 'center',
      justifyContent: 'center',
      width: '80%',
      position: 'relative',
      marginTop: "-40px"
    },
    profileIcon: {
      backgroundColor: '#f0f0f0',
      width: '400px',
      height: '400px',
      borderRadius: '50%',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      margin: 'auto 0',
      marginLeft: '-300px',
      overflow: 'hidden',
    },
    profileImage: {
      width: '100%',
      height: '100%',
      objectFit: 'cover', // Mantiene la imagen dentro del círculo
    },
    form: {
      display: 'flex',
      flexDirection: 'column',
      gap: '10px',
      marginTop: '15px',
    },
    formGroup: {
      textAlign: 'left',
      width: '100%',
    },
    label: {
      fontWeight: 'bold',
      display: 'block',
      marginBottom: '5px',
      color: '#000',
    },
    inputField: {
      width: '250%',
      height: '20px',
      padding: '8px',
      border: '1px solid #ccc',
      borderRadius: '5px',
      color: '#000',
      backgroundColor: '#EBEBF2',
      fontSize: '16px',
    },
    submitButtonContainer: {
      display: 'flex',
      justifyContent: 'center',
      marginTop: '20px',
    },
    submitButton: {
      backgroundColor: '#591202',
      color: 'white',
      padding: '10px',
      border: 'none',
      height: '5%',
      width: '200%',
      borderRadius: '30px',
      fontSize: '20px',
      cursor: 'pointer',
      marginTop: '15px',
      marginLeft: '-200px',
      alignSelf: 'center',
    },
    submitButtonHover: {
      backgroundColor: '#3d1f0e',
    },
    goBackButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '10px 20px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer',
      fontWeight: 'bold',
      fontSize: 16,
      boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
      transition: '0.3s ease',
      whiteSpace: 'nowrap',
      marginRight: 200,
      marginTop: 20
    },
    houseInputField: {
      width: '250%',
      height: '40px',
      padding: '8px',
      border: '1px solid #ccc',
      borderRadius: '5px',
      color: '#000',
      backgroundColor: '#EBEBF2',
      fontSize: '16px',
    },
  };

  const navigate = useNavigate();
  const [casas, setCasas] = useState([]);
  const [form, setForm] = useState({
    nombre: "",
    apellidos: "",
    email: "",
    telefono: "",
    edad: "",
    fechaNacimiento: "",
    houseId: "",
  });

  const baseUrl = import.meta.env.VITE_API_BASE_URL;

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  useEffect(() => {
    const fetchCasas = async () => {
      try {
        const token = localStorage.getItem("token");

        const res = await axios.get(`${baseUrl}/api/casas/activas`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        console.log("Casas recibidas:", res.data);
        setCasas(res.data.data);
      } catch (error) {
        toast.error("Error al obtener casas:", error);
      }
    };

    fetchCasas();
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    const camposObligatorios = [
      "nombre",
      "apellidos",
      "email",
      "telefono",
      "edad",
      "fechaNacimiento",
      "houseId"
    ];
  
    const camposVacios = camposObligatorios.filter((campo) => !form[campo]);
  
    if (camposVacios.length > 0) {
      toast.warning("Por favor completa todos los campos antes de registrar al residente.");
      return;
    }
  
    try {
      const token = localStorage.getItem("token");
  
      const data = {
        nombre: form.nombre,
        apellidos: form.apellidos,
        email: form.email,
        telefono: form.telefono,
        edad: parseInt(form.edad),
        fechaNacimiento: new Date(form.fechaNacimiento).toISOString(),
        house: {
          id: parseInt(form.houseId),
        },
        rol: {
          id: 3
        }
      };
  
      const response = await axios.post(
        `${baseUrl}/api/residente`,
        data,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
  
      toast.success("Residente registrado exitosamente");
  
      setForm({
        nombre: "",
        apellidos: "",
        email: "",
        telefono: "",
        edad: "",
        fechaNacimiento: "",
        houseId: "",
      });
  
    } catch (error) {
      if (error.response && error.response.status === 400) {
        toast.error(error.response.data.message || "Correo o teléfono duplicado");
      } else {
        toast.error("Hubo un error al registrar el residente");
      }
    }
  };  

  return (
    <div style={styles.container}>
      <Sidebar />
      <Banner onLogout={handleLogout} />

      <div style={styles.titleContainer}>
        <button style={styles.goBackButton} className="register-button"
          onClick={() => navigate("/admin/residentes")}>
          Atrás
        </button>

        <h1 style={styles.subtitle}>Registro de residente</h1>
      </div>

      <div style={styles.formContainer}>
        <div style={styles.profileIcon}>
          <img src={usuario} alt="Profile" style={styles.profileImage} />
        </div>

        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Nombre:</label>
            <input
              type="text"
              name="nombre"
              value={form.nombre}
              onChange={handleChange}
              placeholder="Ingresa el nombre"
              style={styles.inputField}
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Apellidos:</label>
            <input
              type="text"
              name="apellidos"
              value={form.apellidos}
              onChange={handleChange}
              placeholder="Ingresa los apellidos"
              style={styles.inputField}
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Correo electrónico:</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="Ingresa el correo"
              style={styles.inputField}
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Edad:</label>
            <input
              type="number"
              name="edad"
              value={form.edad}
              onChange={handleChange}
              placeholder="Ingresa la edad"
              style={styles.inputField}
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Fecha de nacimiento:</label>
            <input
              type="date"
              name="fechaNacimiento"
              value={form.fechaNacimiento}
              onChange={handleChange}
              placeholder="Ingresa la fecha de nacimiento"
              style={styles.inputField}
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Teléfono:</label>
            <input
              type="tel"
              name="telefono"
              value={form.telefono}
              onChange={handleChange}
              placeholder="Ingresa el teléfono"
              style={styles.inputField}
            />
          </div>

          <div style={styles.formGroup}>
            <label style={styles.label}>Casa:</label>
            <select
              name="houseId"
              value={form.houseId}
              onChange={handleChange}
              style={styles.houseInputField}
            >
              <option value="">Selecciona una casa</option>
              {casas.map((casa) => (
                <option key={casa.id} value={casa.id}>
                  {`${casa.direccion} ${casa.calle} #${casa.numeroCasa}`}
                </option>
              ))}
            </select>
          </div>

          <div style={styles.submitButtonContainer}>
            <button type="submit" style={styles.submitButton}>
              Registrar residente
            </button>
          </div>
        </form>
      </div>
      <ToastContainer
        position="bottom-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );
}

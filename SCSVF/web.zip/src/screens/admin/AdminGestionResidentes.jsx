import React, { useEffect, useState } from "react";
import editar from "../../assets/editar-usuario.png";
import contacto from "../../assets/contacto.png";
import profileIcon from "../../assets/usuario.png";
import { useNavigate } from "react-router-dom";
import Banner from "../../components/Header";
import Sidebar from "../../components/SidebarAdmin";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";
const AdminGestionResidentes = () => {
  const navigate = useNavigate();
  const [residentes, setResidentes] = useState([]);
  const [residenteSeleccionado, setResidenteSeleccionado] = useState(null);
  const baseUrl = import.meta.env.VITE_API_BASE_URL;

  const [mostrarModal, setMostrarModal] = useState(false);
  const styles = {
    container: {
      position: "relative", // o simplemente no pongas position
      width: "100%",
      minHeight: "100vh",
      backgroundColor: "#F09560",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "sans-serif",
      left:7,
      top: 5
    },
    header: {
      position: "absolute",
      top: 0,
      left: 0,
      height: "70px",
      width: "100%",
      backgroundColor: "#f2f2f2",
      padding: "16px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      boxSizing: "border-box", // Asegúrate de que el padding no cause desbordamiento
    },
    logo: {
      fontWeight: "bold",
      fontSize: "25px",
      color: "black",
      margin: 0,
    },
    logoutButton: {
      backgroundColor: "#4A1004",
      color: "white",
      padding: "8px 16px",
      border: "none",
      borderRadius: "999px",
      fontSize: "14px",
      fontWeight: "bold",
      height: "40px",
      cursor: "pointer",
    },
    logoutContainer: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
    },
    logoutIcon: {
      width: "36px",
      height: "36px",
      cursor: "pointer",
      transition: "transform 0.2s",
    },
    logoutIconHover: {
      transform: "scale(1.1)",
    },
    title: {
      fontSize: 21,
      fontWeight: 'bold',
      color: '#000'
    },
    profileSection: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginLeft: 'auto'
    },
    logout: {
      backgroundColor: '#591202',
      borderRadius: 35,
      border: 'none',
      cursor: 'pointer',
      color: '#fff',
      padding: '8px 16px'
    },
    profileIcon: {
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 40,
      height: 40,
      borderRadius: '50%',
      backgroundColor: '#fff',
      transition: '0.3s ease',
      overflow: 'hidden'
    },
    titleContainer: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      width: '100%',
      maxWidth: '80%',
      margin: '40px 0',
      flexWrap: 'wrap',
      gap: 20
    },
    subtitle: {
      fontSize: 48,
      fontWeight: 'bold',
      textAlign: 'center',
      color: '#000',
      flex: 1
    },
    
    buttonContainer: {
      position: 'absolute',
      right: 0
    },
    registerButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '10px 20px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer',
      fontWeight: 'bold',
      fontSize: 16,
      boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
      transition: '0.3s ease',
      whiteSpace: 'nowrap'
    },
    buttonIcon: {
      width: 25,
      height: 25
    },
    tableContainer: {
      display: 'flex',
      justifyContent: 'center',
      width: '100%',
      maxWidth: '80%',
      backgroundColor: '#EBEBF2',
      padding: 0,
      borderRadius: 10,
      boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.2)'
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse'
    },
    tableCell: {
      padding: 12,
      border: '1px solid #591202',
      textAlign: 'left',
      color: '#000'
    },
    tableHeader: {
      backgroundColor: '#BF8969',
      color: 'black',
      textAlign: 'center'
    },
    statusActive: {
      color: 'green',
      fontWeight: 'bold'
    },
    statusBlocked: {
      color: 'red',
      fontWeight: 'bold'
    },
    editButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '5px 10px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer'
    },
    ModalLabel: {
      color: 'black',
      fontWeight: 'Bold',
      marginRight: 10
    },
    ModalTitle: {
      color: "black",
      fontWeight: 'bold',
      fontSize: 20
    },
    inputModal: {
      width: '40%',
      marginBottom: 10,
      borderColor: 'black',
      backgroundColor: 'white',
      color: 'black',
      borderRadius: 5
    },
    inputModalShort: {
      width: '8%',
      marginBottom: 10,
      borderColor: 'black',
      backgroundColor: 'white',
      color: 'black',
      borderRadius: 5,
      justifyContent: 'center',
      alignItems: 'center',
      textAlign: 'center  '
    },
    inputModalMedium: {
      width: '20%',
      marginBottom: 10,
      borderColor: 'black',
      backgroundColor: 'white',
      color: 'black',
      borderRadius: 5
    },
    goBackButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '12px 20px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer',
      fontWeight: 'bold',
      fontSize: 16,
      boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
      transition: '0.3s ease',
      whiteSpace: 'nowrap',
    }
  };
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  const [casasActivas, setCasasActivas] = useState([]);

  const fetchResidentes = async () => {
    try {
      const response = await axios.get(`${baseUrl}/api/residente`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      setResidentes(response.data.data || []);
    } catch (error) {
      console.error("Error al obtener residentes:", error);
      toast.error("Error al obtener residentes");
    }
  };

  useEffect(() => {
    fetchResidentes();
  }, []);

  useEffect(() => {
    fetchResidentes();
    fetchCasasActivas();
  }, []);


  const handleEditar = (residente) => {
    setResidenteSeleccionado(residente);
    setMostrarModal(true);
  };

  const camposCompletos = () => {
    const r = residenteSeleccionado;
    return (
      r.nombre?.trim() &&
      r.apellidos?.trim() &&
      r.email?.trim() &&
      r.telefono?.trim() &&
      r.estado?.trim() &&
      r.house?.id
    );
  };
  
  const handleGuardarCambios = async () => {
    if (!camposCompletos()) {
      toast.warning("Por favor completa todos los campos antes de guardar.");
      return;
    }
  
    try {
      await axios.put(
        `${baseUrl}/api/residente/${residenteSeleccionado.id}`,
        residenteSeleccionado,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
  
      toast.success("Residente actualizado correctamente");
      setMostrarModal(false);
      fetchResidentes();
    } catch (error) {
      console.error("Error al actualizar residente:", error);
      toast.error("Error al actualizar residente");
    }
  };

  const fetchCasasActivas = async () => {
    try {
      const response = await axios.get(`${baseUrl}/api/casas/activas`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      setCasasActivas(response.data.data || []);
    } catch (error) {
      console.error("Error al obtener casas activas:", error);
    }
  };

  return (
    <div style={styles.container}>
      <Sidebar />
      <Banner onLogout={handleLogout} />

      <div style={styles.titleContainer}>
        <button style={styles.goBackButton} className="register-button"
          onClick={() => navigate("/admin/admin-home")}>
          Atrás
        </button>
        <h1 style={styles.subtitle}>Residentes</h1>
        <button
          style={styles.registerButton}
          onClick={() => navigate("/admin/residentes/registro")}
        >
          <img style={styles.buttonIcon} src={contacto} alt="Profile" />
          Registrar nuevo residente
        </button>
      </div>

      <div style={styles.tableContainer}>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>ID</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Nombre</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Correo</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Telefono</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>
                Fecha de nacimiento
              </th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Dirección</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Estatus</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {residentes.map((residente) => (
              <tr key={residente.id}>
                <td style={styles.tableCell}>{residente.id}</td>
                <td style={styles.tableCell}>
                  {`${residente.nombre} ${residente.apellidos}`}
                </td>
                <td style={styles.tableCell}>{residente.email}</td>
                <td style={styles.tableCell}>{residente.telefono}</td>
                <td style={styles.tableCell}>{residente.fechaNacimiento}</td>
                <td style={styles.tableCell}>
                  {`${residente.house?.direccion}, Calle ${residente.house?.calle}, No. ${residente.house?.numeroCasa}`}
                </td>
                <td
                  style={{
                    ...styles.tableCell,
                    ...(residente.estado === "Activo"
                      ? styles.statusActive
                      : styles.statusBlocked),
                  }}
                >
                  {residente.estado}
                </td>
                <td style={styles.tableCell}>
                  <button
                    style={styles.editButton}
                    onClick={() => handleEditar(residente)}
                  >
                    <img style={styles.buttonIcon} src={editar} alt="Editar" />
                    Editar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {mostrarModal && residenteSeleccionado && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 20,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0,0,0,0.4)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              backgroundColor: "#fff",
              padding: 30,
              borderRadius: 10,
              width: "90%",
              maxWidth: 500,
              boxShadow: "0 0 10px rgba(0,0,0,0.3)",
            }}
          >
            <h2 style={{ color: 'black' }}>Editar Residente</h2>

            <label style={styles.ModalLabel}>Nombre:</label>
            <input
              type="text"
              value={residenteSeleccionado.nombre}
              onChange={(e) =>
                setResidenteSeleccionado({
                  ...residenteSeleccionado,
                  nombre: e.target.value,
                })
              }
              style={styles.inputModal}
            />
            <br />

            <label style={styles.ModalLabel}>Apellidos:</label>
            <input
              type="text"
              value={residenteSeleccionado.apellidos}
              onChange={(e) =>
                setResidenteSeleccionado({
                  ...residenteSeleccionado,
                  apellidos: e.target.value,
                })
              }
              style={styles.inputModal}
            />
            <br />

            <label style={styles.ModalLabel}>Correo electrónico:</label>
            <input
              type="email"
              value={residenteSeleccionado.email}
              onChange={(e) =>
                setResidenteSeleccionado({
                  ...residenteSeleccionado,
                  email: e.target.value,
                })
              }
              style={styles.inputModal}
            />
            <br />

            <label style={styles.ModalLabel}>Teléfono:</label>
            <input
              type="tel"
              value={residenteSeleccionado.telefono}
              onChange={(e) =>
                setResidenteSeleccionado({
                  ...residenteSeleccionado,
                  telefono: e.target.value,
                })
              }
              style={styles.inputModal}
            />
            <br />

            <label style={styles.ModalLabel}>Estado:</label>
            <select
              value={residenteSeleccionado.estado}
              onChange={(e) =>
                setResidenteSeleccionado({
                  ...residenteSeleccionado,
                  estado: e.target.value,
                })
              }
              style={styles.inputModalMedium}
            >
              <option value="Activo">Activo</option>
              <option value="Inactivo">Inactivo</option>
            </select>
            <br />
            <h4 style={styles.ModalTitle}>Información de la Casa</h4>

            <label style={styles.ModalLabel}>Casa asignada:</label>
            <select
              value={residenteSeleccionado.house?.id || ""}
              onChange={(e) => {
                const selectedHouse = casasActivas.find(h => h.id === parseInt(e.target.value));
                setResidenteSeleccionado({
                  ...residenteSeleccionado,
                  house: selectedHouse
                });
              }}
              style={styles.inputModal}
            >
              <option value="">Selecciona una casa</option>
              {casasActivas.map((casa) => (
                <option key={casa.id} value={casa.id}>
                  {`${casa.direccion}, Calle ${casa.calle}, No. ${casa.numeroCasa}`}
                </option>
              ))}
            </select>
            <br />

            <div style={{ marginTop: 20, display: "flex", gap: 10 }}>
              <button style={{ padding: '8px 16px', backgroundColor: '#591202', color: 'white', border: 'none', cursor: 'pointer', borderRadius: 8, fontWeight: 'bold' }} onClick={handleGuardarCambios}>Guardar</button>
              <button style={{ padding: '8px 16px', backgroundColor: '#ccc', border: 'none', borderRadius: 8, cursor: 'pointer',fontWeight: 'bold' }} onClick={() => setMostrarModal(false)}>Cancelar</button>
            </div>
          </div>
        </div>
      )
      }
      <ToastContainer
        position="bottom-right"
        autoClose={3000} // tiempo en ms que el toast permanece visible
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div >
  );
};

export default AdminGestionResidentes;

import React, { useEffect, useState } from "react";
import axios from "axios";
import editar from "../../assets/editar-usuario.png";
import contacto from "../../assets/contacto.png";
import profileIcon from "../../assets/usuario.png";
import { useNavigate } from "react-router-dom";
import Banner from "../../components/Header"; // Ajusta la ruta si es diferente
import Sidebar from "../../components/SidebarAdmin";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const AdminGestionEmpleados = () => {
  const [empleados, setEmpleados] = useState([]);
  const [loading, setLoading] = useState(true);
  const baseUrl = import.meta.env.VITE_API_BASE_URL;

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  const navigate = useNavigate();

  const [showModal, setShowModal] = useState(false);
  const [empleadoActual, setEmpleadoActual] = useState(null);

  const abrirModal = (empleado) => {
    setEmpleadoActual(empleado);
    setShowModal(true);
  };

  const camposValidos = () => {
    const { nombre, apellidos, email, telefono, direccion, calle, estado } = empleadoActual;
    return (
      nombre?.trim() &&
      apellidos?.trim() &&
      email?.trim() &&
      telefono?.trim() &&
      direccion?.trim() &&
      calle?.trim() &&
      estado?.trim()
    );
  };



  const fetchEmpleados = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        window.location.href = "/login";
        return;
      }

      const response = await axios.get(`${baseUrl}/api/empleados/guardias`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.data && Array.isArray(response.data.data)) {
        setEmpleados(response.data.data);
      } else {
        console.error("Formato inesperado en la respuesta:", response.data);
      }
    } catch (error) {
      console.error("Error al obtener empleados:", error);
      setEmpleados([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmpleados();
  }, []);

  const styles = {
    container: {
      position: "relative", // o simplemente no pongas position
      width: "100%",
      minHeight: "100vh",
      backgroundColor: "#F09560",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "sans-serif",
      left:7,
      top: 5
    },
    header: {
      position: "absolute",
      top: 0,
      left: 0,
      height: "70px",
      width: "100%",
      backgroundColor: "#f2f2f2",
      padding: "16px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      boxSizing: "border-box",
    },
    logo: {
      fontWeight: "bold",
      fontSize: "25px",
      color: "black",
      margin: 0,
    },
    logoutButton: {
      backgroundColor: "#4A1004",
      color: "white",
      padding: "8px 16px",
      border: "none",
      borderRadius: "999px",
      fontSize: "14px",
      fontWeight: "bold",
      height: "40px",
      cursor: "pointer",
    },
    logoutContainer: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
    },
    logoutIcon: {
      width: "36px",
      height: "36px",
      cursor: "pointer",
      transition: "transform 0.2s",
    },
    logoutIconHover: {
      transform: "scale(1.1)",
    },
    title: {
      fontSize: 21,
      fontWeight: 'bold',
      color: '#000'
    },
    profileSection: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginLeft: 'auto'
    },
    logout: {
      backgroundColor: '#591202',
      borderRadius: 35,
      border: 'none',
      cursor: 'pointer',
      color: '#fff',
      padding: '8px 16px'
    },
    profileIcon: {
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 40,
      height: 40,
      borderRadius: '50%',
      backgroundColor: '#fff',
      transition: '0.3s ease',
      overflow: 'hidden'
    },
    titleContainer: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      width: '100%',
      maxWidth: '80%',
      margin: '40px 0',
      flexWrap: 'wrap',
      gap: 20
    },
    subtitle: {
      fontSize: 48,
      fontWeight: 'bold',
      textAlign: 'center',
      color: '#000',
      flex: 1
    },
    
    buttonContainer: {
      position: 'absolute',
      right: 0
    },
    registerButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '10px 20px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer',
      fontWeight: 'bold',
      fontSize: 16,
      boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
      transition: '0.3s ease',
      whiteSpace: 'nowrap'
    },
    buttonIcon: {
      width: 25,
      height: 25
    },
    tableContainer: {
      display: 'flex',
      justifyContent: 'center',
      width: '100%',
      maxWidth: '80%',
      backgroundColor: '#EBEBF2',
      padding: 0,
      borderRadius: 10,
      boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.2)'
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse'
    },
    tableCell: {
      padding: 12,
      border: '1px solid #591202',
      textAlign: 'center',
      color: '#000',

    },
    tableHeader: {
      backgroundColor: '#BF8969',
      color: 'black',
      textAlign: 'center'
    },
    statusActive: {
      color: 'green',
      fontWeight: 'bold'
    },
    statusBlocked: {
      color: 'red',
      fontWeight: 'bold'
    },
    editButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '5px 10px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer'
    },
    inputModal: {
      width: '100%',
      marginBottom: 10,
      backgroundColor: 'white',
      color: 'black',
      borderRadius: 5
    },
    labelModal: {
      color: 'black',
      fontWeight: 'bold'
    },
    goBackButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      backgroundColor: '#591202',
      color: 'white',
      padding: '10px 20px',
      border: 'none',
      borderRadius: 35,
      cursor: 'pointer',
      fontWeight: 'bold',
      fontSize: 16,
      boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
      transition: '0.3s ease',
      whiteSpace: 'nowrap',
    }
  };

  return (
    <div style={styles.container} className="container">
      <Sidebar />
      <Banner onLogout={handleLogout} />

      <div style={styles.titleContainer} className="title-container">

        <button style={styles.goBackButton} className="register-button"
          onClick={() => navigate("/admin/admin-home")}>
          Atrás
        </button>

        <h1 style={styles.subtitle} className="subtitle">Guardias</h1>

        <button style={styles.registerButton} className="register-button"
          onClick={() => navigate("/admin/guardias/registro")}
        >
          <img style={styles.buttonIcon} src={contacto} alt="Profile" className="button-icon" />
          Registrar nuevo guardia
        </button>
      </div>

      <div style={styles.tableContainer} className="table-container">
        <table style={styles.table} className="table">
          <thead>
            <tr>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>ID</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Nombre</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Apellidos</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Correo</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Fecha Nacimiento</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Teléfono</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Dirección</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Estado</th>
              <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="9" style={styles.tableCell}>Cargando...</td>
              </tr>
            ) : (
              empleados.map((empleado) => (
                <tr key={empleado.id}>
                  <td style={styles.tableCell}>{empleado.id}</td>
                  <td style={styles.tableCell}>{empleado.nombre}</td>
                  <td style={styles.tableCell}>{empleado.apellidos}</td>
                  <td style={styles.tableCell}>{empleado.email}</td>
                  <td style={styles.tableCell}>{empleado.fechaNacimiento}</td>
                  <td style={styles.tableCell}>{empleado.telefono}</td>
                  <td style={styles.tableCell}>{`${empleado.direccion} Calle ${empleado.calle}`}</td>
                  <td
                    style={{
                      ...styles.tableCell,
                      ...(empleado.estado === "Activo" ? styles.statusActive : styles.statusBlocked),
                    }}
                  >
                    {empleado.estado}
                  </td>
                  <td style={styles.tableCell}>
                    <button style={styles.editButton} className="edit-button" onClick={() => abrirModal(empleado)}>
                      <img style={styles.buttonIcon} src={editar} alt="Editar" className="button-icon" />
                      Editar
                    </button>

                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      {showModal && empleadoActual && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex',
          justifyContent: 'center', alignItems: 'center', zIndex: 999
        }}>
          <div style={{
            backgroundColor: 'white', padding: 20, borderRadius: 10,
            width: '400px', maxWidth: '90%'
          }}>
            <h2 style={{ fontWeight: 'bold', color: 'black' }}>Editar guardia</h2>
            <form onSubmit={async (e) => {
              e.preventDefault();
              if (!camposValidos()) {
                toast.warning("Por favor completa todos los campos antes de guardar.");
                return;
              }

              try {
                const token = localStorage.getItem("token");
                await axios.put(`${baseUrl}/api/empleados/${empleadoActual.id}`, empleadoActual, {
                  headers: { Authorization: `Bearer ${token}` }
                });
                await fetchEmpleados();
                setShowModal(false);
                toast.success("Guardia actualizado exitosamente");
              } catch (error) {
                toast.error("Error al actualizar");
              }
            }}>

              <label style={styles.labelModal}>Nombre</label>
              <input
                type="text"
                placeholder="Nombre"
                value={empleadoActual.nombre}
                onChange={(e) => setEmpleadoActual({ ...empleadoActual, nombre: e.target.value })}
                style={styles.inputModal}
              />
              <label style={styles.labelModal}>Apellidos</label>
              <input
                type="text"
                placeholder="Apellidos"
                value={empleadoActual.apellidos}
                onChange={(e) => setEmpleadoActual({ ...empleadoActual, apellidos: e.target.value })}
                style={styles.inputModal}
              />
              <label style={styles.labelModal}>Correo</label>
              <input
                type="email"
                placeholder="Correo"
                value={empleadoActual.email}
                onChange={(e) => setEmpleadoActual({ ...empleadoActual, email: e.target.value })}
                style={styles.inputModal}
              />
              <label style={styles.labelModal}>Teléfono</label>
              <input
                type="text"
                placeholder="Teléfono"
                value={empleadoActual.telefono}
                onChange={(e) => setEmpleadoActual({ ...empleadoActual, telefono: e.target.value })}
                style={styles.inputModal}
              />
              <label style={styles.labelModal}>Dirección</label>
              <input
                type="text"
                placeholder="Dirección"
                value={empleadoActual.direccion}
                onChange={(e) => setEmpleadoActual({ ...empleadoActual, direccion: e.target.value })}
                style={styles.inputModal}
              />
              <label style={styles.labelModal}>Calle</label>
              <input
                type="text"
                placeholder="Calle"
                value={empleadoActual.calle}
                onChange={(e) => setEmpleadoActual({ ...empleadoActual, calle: e.target.value })}
                style={styles.inputModal}
              />
              <label style={styles.labelModal}>Estado</label>
              <select
                value={empleadoActual.estado}
                onChange={(e) =>
                  setEmpleadoActual({ ...empleadoActual, estado: e.target.value })
                }
                style={styles.inputModal}
              >
                <option value="Activo">Activo</option>
                <option value="Inactivo">Inactivo</option>
              </select>


              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 20 }}>
                <button type="submit" style={{ padding: '8px 16px', backgroundColor: '#591202', color: 'white', border: 'none',  cursor: 'pointer', borderRadius: 8, fontWeight: 'bold' }}>Guardar</button>
                <button onClick={() => setShowModal(false)} style={{ padding: '8px 16px', backgroundColor: '#ccc', border: 'none',cursor: 'pointer', borderRadius: 8, fontWeight: 'bold' }}>Cancelar</button>
              </div>
            </form>
          </div>
        </div>
      )}
      <ToastContainer
        position="bottom-right"
        autoClose={3000} // tiempo en ms que el toast permanece visible
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );
};

export default AdminGestionEmpleados;

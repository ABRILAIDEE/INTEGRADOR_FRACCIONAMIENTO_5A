import React from "react";
import { useNavigate, useLocation } from "react-router-dom";

const styles = {
  container: {
    height: "100vh",
    width: "100vw",
    backgroundColor: "#fef2f2",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    fontFamily: "sans-serif",
    textAlign: "center",
    padding: "20px",
  },
  title: {
    fontSize: "48px",
    color: "#b91c1c",
    marginBottom: "16px",
  },
  subtitle: {
    fontSize: "20px",
    color: "#7f1d1d",
    marginBottom: "32px",
  },
  button: {
    padding: "12px 24px",
    backgroundColor: "#b91c1c",
    color: "#ffffff",
    border: "none",
    borderRadius: "8px",
    fontSize: "16px",
    cursor: "pointer",
  }
};

const Unauthorized = () => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate("/"); // Ajusta si tienes otra ruta inicial
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Acceso no autorizado</h1>
      <p style={styles.subtitle}>
        No tienes permiso para acceder a esta página.
      </p>
      <button style={styles.button} onClick={handleGoBack}>
        Volver al inicio
      </button>
    </div>
  );
};

export default Unauthorized;

import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import ResidentCreateVisit from "../ResidentRegistroVisita";
import ResidentProfile from "../ResidentProfile";
import ResidentHome from "../ResidentHome";
import ResidentQR from "../ResidentQR";
import ResidentVisits from "../ResidentVisitas";
import Unauthorized from "../../Unauthorized";
import NotFound from "../../NotFound";
const ResidentRoutes = () => {
  return (
    <Routes>
      <Route path="resident-home" element={<ResidentHome />} />
      <Route path="profile" element={<ResidentProfile />} />
      <Route path="create-visit" element={<ResidentCreateVisit />} />
      <Route path="visits" element={<ResidentVisits />} />
      <Route path="qr" element={<ResidentQR />} />
      <Route path="unauthorized" element={<Unauthorized />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default ResidentRoutes;

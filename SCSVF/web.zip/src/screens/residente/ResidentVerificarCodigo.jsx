import React, { useState, useEffect } from "react";
import userIcon from "../../assets/usuario.png";
import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

const styles = {
  container: {
    width: "100%",
    minHeight: "100vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "fixed",
    fontFamily: "sans-serif",
    left: 0,
    top: 0
  },
  header: {
    position: "absolute",
    top: 0,
    left: 0,
    height: "70px",
    width: "100%",
    backgroundColor: "#f2f2f2",
    padding: "16px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    boxSizing: "border-box", // Asegura que el padding no cause desbordamiento
  },
  logo: {
    fontWeight: "bold",
    fontSize: "25px",
    color: "black",
    margin: 0,
  },
  adminButton: {
    backgroundColor: "#4A1004",
    color: "white",
    padding: "8px 16px",
    border: "none",
    borderRadius: "999px",
    fontSize: "14px",
    fontWeight: "bold",
    height: "40px",
    cursor: "pointer",
  },
  loginBox: {
    marginTop: "60px",
    textAlign: "center",
  },
  icon: {
    marginBottom: "20px",
  },
  iconImg: {
    width: "200px",
    height: "200px",
    marginBottom: "-10px",
    objectFit: "contain",
  },
  titulo: {
    margin: "15px",
    fontSize: "50px",
    color: "black",
  },
  inputCode: {
    display: "block",
    margin: "0 auto 16px auto",
    padding: "12px 20px",
    borderRadius: "999px",
    width: "460px",
    textAlign: "center",
    backgroundColor: "#FFFFFF",
    fontSize: "16px",
    color: "black",
    border: "none",
  },
  submitButton: {
    display: "block",
    margin: "0 auto",
    backgroundColor: "#591202",
    color: "white",
    padding: "12px 20px",
    width: "500px",
    height: "40px",
    border: "none",
    borderRadius: "999px",
    fontSize: "16px",
    cursor: "pointer",
  },
};

export default function ResidentLoginCode() {
  const location = useLocation();
  const telefono = location.state?.telefono || "";
  const [codigo, setCodigo] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const baseUrl = import.meta.env.VITE_API_BASE_URL;
  const handleLogin = async () => {
    try {
      const response = await axios.post(`${baseUrl}/auth/verify-code`, {
        telefono,
        codigo
      });

      const token = response.data.data;

      if (!token || typeof token !== "string" || !token.includes(".")) {
        throw new Error("Token inválido recibido");
      }

      localStorage.setItem("token", token);
      localStorage.setItem("role", "RESIDENTE");

      toast.success("Se inició sesión exitosamente");
      navigate("/resident/resident-home", {
        state: { toastMessage: "Se inició sesión exitosamente" }
      });
    } catch (err) {
      console.error("Error en login:", err);

      toast.error("Tu código no es el correcto");

      if (err.response?.data?.message) {
        setError(err.response.data.message);
      } else {
        setError("Tu código no es el correcto");
      }
    }
  };


  useEffect(() => {
    if (location.state?.toastMessage) {
      toast.success(location.state.toastMessage);
    }
  }, [location.state]);

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h1 style={styles.logo}>SCSVF</h1>
        <button style={styles.adminButton} onClick={() => navigate("/scsvf/admin")}>Soy Administrador</button>
      </div>

      {/* Content */}
      <div style={styles.loginBox}>
        <div style={styles.icon}>
          <img src={userIcon} alt="User Icon" style={styles.iconImg} />
        </div>

        <h1 style={styles.titulo}>SCSVF</h1>
        <input type="text"
          value={telefono}
          placeholder="Ingresa tu numero telefonico"
          disabled={true}
          style={styles.inputCode} />

        <input type="text"
          onChange={(e) => setCodigo(e.target.value)}
          placeholder="Ingresa tu codigo"
          style={styles.inputCode} />
        <button style={styles.submitButton} onClick={handleLogin}>Ingresar</button>
      </div>
      <ToastContainer
        position="bottom-right"
        autoClose={3000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
}
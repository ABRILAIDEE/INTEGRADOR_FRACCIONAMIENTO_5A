import { useState, useEffect, useRef } from "react";
import Banner from "../../components/HeaderRes";
import SidebarRes from "../../components/SidebarRes";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";
import { useNavigate } from "react-router-dom";

const styles = {
  container: {
    width: "100%",
    minHeight: "100vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "fixed",
    fontFamily: "sans-serif",
    left: 0,
    top:0
  },
  titleContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '90%',
    maxWidth: '70%',
    margin: '40px',
    flexWrap: 'wrap',
    gap: 20,
    marginTop: 80
  },
  title: {
    fontSize: 64,
    fontWeight: 'bold',
    flexGrow: 1,
    textAlign: 'center',
    color: '#000',
    margin: 0
  },
  formContainer: {
    display: 'flex',
    flexDirection: 'column',
    width: '80%',
    maxWidth: '1200px',
  },
  formRow: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '20px',
    marginBottom: '20px',
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column',
    flex: 1,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: '5px',
    color: '#000',
  },
  input: {
    padding: '12px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    backgroundColor: '#FFFFFF',
    fontSize: '16px',
    color: 'black'
  },
  dateTimeContainer: {
    display: 'flex',
    gap: '15px',
  },
  dateInput: {
    width: '120px',
    padding: '12px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    backgroundColor: '#591202',
    fontSize: '16px',
    color:'white'
  },
  timeInput: {
    width: '100px',
    padding: '12px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    backgroundColor: '#591202',
    fontSize: '16px',
    color:'white'
  },
  imageUploadContainer: {
    display: 'flex',
    alignItems: 'center',
  },
  imageInput: {
    flex: 1,
    padding: '12px',
    border: '1px solid #ccc',
    borderRadius: '5px 0 0 5px',
    backgroundColor: '#FFFFFF',
    fontSize: '16px',
  },
  cameraButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '42px',
    height: '42px',
    backgroundColor: '#FFFFFF',
    border: '1px solid #ccc',
    borderLeft: 'none',
    borderRadius: '0 5px 5px 0',
    cursor: 'pointer',
  },
  cameraIcon: {
    width: '25px',
    height: '25px',
  },
  buttonContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '20px',
    marginTop: '30px',
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#591202',
    color: 'white',
    padding: '15px',
    border: 'none',
    borderRadius: '30px',
    fontSize: '18px',
    fontWeight: 'bold',
    cursor: 'pointer',
    textAlign: 'center',
  },
  goBackButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#591202',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: 35,
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: 16,
    boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
    transition: '0.3s ease',
    whiteSpace: 'nowrap',

  }
};

export default function ResidentCreateVisit() {
  const [form, setForm] = useState({
    nombre: "",
    numeroPersonas: "",
    descripcion: "",
    tipoVisita: "",
    placasVehiculo: "",
    palabrasClave: "",
    ineImagen: "",
    numeroCasa: "",
    fecha: "",
    hora: "",
    estatus: "Pendiente",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  const baseUrl = import.meta.env.VITE_API_BASE_URL;

  const [residentInfo, setResidentInfo] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");

    // Validación de campos vacíos
    const requiredFields = [
      { name: "nombre", label: "Nombre del visitante" },
      { name: "numeroPersonas", label: "Número de personas" },
      { name: "descripcion", label: "Descripción" },
      { name: "tipoVisita", label: "Tipo de visita" },
      { name: "fecha", label: "Fecha" },
      { name: "hora", label: "Hora" },
    ];

    for (const field of requiredFields) {
      if (!form[field.name] || form[field.name].trim() === "") {
        toast.warning(`Por favor, llena el campo: ${field.label}`);
        return;
      }
    }

    // Validaciones de fecha y hora
    const now = new Date();
    const nowPlusTwoHours = new Date(now.getTime() + 2 * 60 * 60 * 1000);
    const [hour, minute] = form.hora.split(":");

    const visitDateTime = new Date(`${form.fecha}T${hour}:${minute}`);

    if (visitDateTime < now) {
      toast.warning("La fecha y hora de la visita no pueden ser anteriores a la actual");
      return;
    }

    const todayStr = now.toISOString().split("T")[0];
    if (form.fecha === todayStr && visitDateTime < nowPlusTwoHours) {
      toast.warning("Si la visita es hoy, debe ser al menos 2 horas más adelante que la hora actual");
      return;
    }

    try {
      const payload = {
        fecha: form.fecha,
        hora: form.hora,
        numeroPersonas: parseInt(form.numeroPersonas),
        descripcion: form.descripcion,
        tipoVisita: form.tipoVisita,
        placasVehiculo: form.placasVehiculo,
        palabraClave: form.palabrasClave,
        nombreVisitante: form.nombre,
        houseId: residentInfo?.house?.id,
        statusId: 1,
      };

      const response = await axios.post(`${baseUrl}/api/visitas/me`, payload, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });

      const qrUrl = response.data.qrUrl;
      toast.success("Visita creada correctamente");
      navigate("/resident/qr", { state: { qrUrl } });

    } catch (error) {
      toast.error("Error al crear la visita");
      console.error(error);
    }
  };


  //Fecha actual
  const getMinTime = () => {
    const today = new Date().toISOString().split("T")[0];

    if (form.fecha === today) {
      const now = new Date();
      const twoHoursLater = new Date(now.getTime() + 2 * 60 * 60 * 1000);
      const hours = String(twoHoursLater.getHours()).padStart(2, "0");
      const minutes = String(twoHoursLater.getMinutes()).padStart(2, "0");
      return `${hours}:${minutes}`;
    }

    return "00:00";
  };


  useEffect(() => {
    const fetchResidentInfo = async () => {
      const token = localStorage.getItem("token");
      try {
        const response = await axios.get(`${baseUrl}/api/residente/me`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        setResidentInfo(response.data.data);
      } catch (error) {
        toast.error("Error al cargar información del residente");
        console.error(error);
      }
    };

    fetchResidentInfo();
  }, []);


  const navigate = useNavigate();

  const handleShareLink = async () => {
    const token = localStorage.getItem("token");
    try {
      const response = await axios.get(`${baseUrl}/api/external/generate-visit-link`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const url = response.data.url;
      await navigator.clipboard.writeText(url);
      toast.success("Enlace copiado al portapapeles");
    } catch (error) {
      toast.error("Error al generar el enlace");
      console.error(error);
    }
  };


  return (
    <div style={styles.container}>
      <SidebarRes />
      <Banner onLogout={handleLogout} />

      <div style={styles.titleContainer}>
        <button style={styles.goBackButton} className="register-button"
          onClick={() => navigate("/resident/resident-home")}>
          Atrás
        </button>
        <h1 style={styles.title}>Crear visita</h1>
      </div>

      <form onSubmit={handleSubmit} style={styles.formContainer}>
        <div style={styles.formRow}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Asistente(s) a la visita:</label>
            <input
              type="text"
              name="nombre"
              placeholder="Juan Pérez"
              value={form.nombre}
              onChange={handleChange}
              style={styles.input}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Número de personas:</label>
            <input
              type="number"
              name="numeroPersonas"
              placeholder="5"
              value={form.numeroPersonas}
              onChange={handleChange}
              style={styles.input}
            />
          </div>
        </div>

        <div style={styles.formRow}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Descripción:</label>
            <input
              type="text"
              name="descripcion"
              placeholder="Vamos con el fin de saludar a una amiga"
              value={form.descripcion}
              onChange={handleChange}
              style={styles.input}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Tipo de visitas:</label>
            <select
              name="tipoVisita"
              value={form.tipoVisita}
              onChange={handleChange}
              style={styles.input}
            >
              <option value="">Selecciona un tipo</option>
              <option value="Técnica">Técnica</option>
              <option value="Familiar">Familiar</option>
            </select>

          </div>
        </div>

        <div style={styles.formRow}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Placas del vehículo (si aplica):</label>
            <input
              type="text"
              name="placasVehiculo"
              placeholder="OSK-128-9FKL"
              value={form.placasVehiculo}
              onChange={handleChange}
              style={styles.input}
            />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Palabras clave (si es el caso):</label>
            <input
              type="text"
              name="palabrasClave"
              placeholder="Platano"
              value={form.palabrasClave}
              onChange={handleChange}
              style={styles.input}
            />
          </div>
        </div>

        <div style={styles.formRow}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Fecha y hora de visita</label>
            <div style={styles.dateTimeContainer}>
              <input
                type="date"
                name="fecha"
                placeholder="12/12/2025"
                value={form.fecha}
                onChange={handleChange}
                min={new Date().toISOString().split("T")[0]}
                style={styles.dateInput}
              />
              <input
                type="time"
                name="hora"
                placeholder="00:00"
                value={form.hora}
                onChange={handleChange}
                min={getMinTime()}
                key={form.fecha} // Esto es crucial para que el input se "reinicie" cuando cambies la fecha
                style={styles.timeInput}
              />
            </div>
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Casa:</label>
            <input
              type="text"
              value={residentInfo?.house?.numeroCasa || ""}
              readOnly
              style={{ ...styles.input, backgroundColor: "#e0e0e0", fontWeight: "bold" }}
            />
          </div>

        </div>
        <div style={styles.formRow}>
          <div style={styles.formGroup}>
          </div>

        </div>

        <div style={styles.buttonContainer}>
          <button type="button" style={styles.actionButton} onClick={handleShareLink}>
            Compartir enlace
          </button>
          <button type="submit" style={styles.actionButton}>
            Crear visita
          </button>
        </div>
      </form>
      <ToastContainer
        position="bottom-right"
        autoClose={3000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
}
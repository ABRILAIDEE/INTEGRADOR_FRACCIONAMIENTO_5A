import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import BannerRes from "../../components/HeaderRes";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import SidebarRes from "../../components/SidebarRes";

const styles = {
  container: {
    position: "relative",
    width: "100%",
    minHeight: "100vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "sans-serif",
    left:7,
    top: 5
  },
  title: {
    fontSize: 21,
    fontWeight: 'bold',
    color: '#000'
  },
  titleContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    maxWidth: '80%',
    margin: '40px',
    flexWrap: 'wrap',
    gap: 20,
    marginTop: 80
  },
  subtitle: {
    fontSize: 64,
    fontWeight: 'bold',
    flexGrow: 1,
    textAlign: 'center',
    color: '#000',
    margin: 0
  },
  buttonContainer: {
    position: 'absolute',
    right: 0
  },
  buttonIcon: {
    width: 25,
    height: 25
  },
  tableContainer: {
    display: 'flex',
    justifyContent: 'center',
    width: '100%',
    maxWidth: '80%',
    backgroundColor: '#EBEBF2',
    padding: 0,
    borderRadius: 10,
    boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.2)'
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse'
  },
  tableCell: {
    padding: 12,
    border: '1px solid #591202',
    textAlign: 'center',
    color: '#000'
  },
  tableHeader: {
    backgroundColor: '#BF8969',
    color: 'black',
    textAlign: 'center'
  },
  goBackButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#591202',
    color: 'white',
    padding: '10px 20px',
    border: 'none',
    borderRadius: 35,
    cursor: 'pointer',
    fontWeight: 'bold',
    fontSize: 16,
    boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
    transition: '0.3s ease',
    whiteSpace: 'nowrap',

  }
};

const ResidentVisits = () => {

  const navigate = useNavigate();
  const baseUrl = import.meta.env.VITE_API_BASE_URL;
  const [visitas, setVisitas] = useState([]);

  useEffect(() => {
    const fetchVisitas = async () => {
      try {
        const token = localStorage.getItem("token"); // o desde donde lo guardes tú
        const response = await axios.get(`${baseUrl}/api/visitas/me`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });

        const { data } = response.data; // porque usas CustomResponseEntity
        setVisitas(data);
      } catch (error) {
        console.error("Error al obtener visitas:", error);
        toast.error("No se pudieron cargar las visitas.");
      }
    };

    fetchVisitas();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div style={styles.container} className="container">
      <SidebarRes />
      <BannerRes onLogout={handleLogout}/>

      <div style={styles.titleContainer} className="title-container">
        <button style={styles.goBackButton} className="register-button"
          onClick={() => navigate("/resident/resident-home")}>
          Atrás
        </button>
        <h1 style={styles.subtitle} className="subtitle">Mis Visitas</h1>
      </div>

      <div style={styles.tableContainer} className="table-container">
        {visitas.length === 0 ? (
          <p style={{ padding: 20, fontSize: 18, fontWeight: 'bold', color: 'black' }}>
            No tienes visitas aún
          </p>
        ) : (
          <table style={styles.table} className="table">
            <thead>
              <tr>
                <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Visitante (s)</th>
                <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Tipo Visita</th>
                <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Fecha / Hora</th>
                <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Descripcion</th>
                <th style={{ ...styles.tableCell, ...styles.tableHeader }}>Estado</th>
              </tr>
            </thead>
            <tbody>
              {visitas.map((visita) => (
                <tr key={visita.id}>
                  <td style={styles.tableCell}>{visita.nombreVisitante}</td>
                  <td style={styles.tableCell}>{visita.tipoVisita}</td>
                  <td style={styles.tableCell}>{visita.fecha} / {visita.hora}</td>
                  <td style={styles.tableCell}>{visita.descripcion}</td>
                  <td
                    style={{
                      ...styles.tableCell,
                      color:
                        visita.estado === "Pendiente" ? "gray" :
                          visita.estado === "En progreso" ? "green" :
                            visita.estado === "Terminada" ? "black" :
                              (visita.estado === "Caducada" || visita.estado === "Cancelada") ? "red" :
                                "inherit",
                      fontWeight: "bold",
                    }}
                  >
                    {visita.estado}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <ToastContainer
        position="bottom-right"
        autoClose={3000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
};

export default ResidentVisits;
import React from "react";
import userIcon from "../../assets/vecindario.png";
import axios from "axios";
import SidebarRes from "../../components/SidebarRes";
import BannerRes from "../../components/HeaderRes";
import { useNavigate, useLocation } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const styles = {
  container: {
    width: "100%",
    minHeight: "100vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "fixed",
    fontFamily: "sans-serif",
    left: 0,
    top:0
  },
  loginBox: {
    marginTop: "60px",
    textAlign: "center",
  },
  icon: {
    marginBottom: "60px",
  },
  iconImg: {
    width: "200px",
    height: "200px",
    marginBottom: "-40px",
    objectFit: "contain",
  },
  titleHome: {
    color: "#000",
  },
  createVisitButton: {
    display: "block",
    margin: "0 auto",
    backgroundColor: "#EBEBF2",
    color: "#000",
    padding: "12px 20px",
    width: "500px",
    height: "40px",
    border: "none",
    borderRadius: "999px",
    fontSize: "20px",
    cursor: "pointer",
    marginBottom: "20px",
    fontWeight: "bold",
  },
  myVisitsButton: {
    display: "block",
    margin: "0 auto",
    backgroundColor: "#EBEBF2",
    color: "#000",
    padding: "12px 20px",
    width: "500px",
    height: "40px",
    border: "none",
    borderRadius: "999px",
    fontSize: "20px",
    cursor: "pointer",
    fontWeight: "bold",
  },
};

export default function ResidentHome() {
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div style={styles.container}>
      <SidebarRes/>
     <BannerRes onLogout={handleLogout} /> 

      <div style={styles.loginBox}>
        <h1 style={styles.titleHome}>¿Qué vas a hacer hoy?</h1>
        <div style={styles.icon}>
          <img src={userIcon} alt="User Icon" style={styles.iconImg} />
        </div>
        <button style={styles.createVisitButton} onClick={() => navigate("/resident/create-visit")}>Crear Visitas</button>
        <button style={styles.myVisitsButton} onClick={() => navigate("/resident/visits")}>Mis Visitas</button>
      </div>
      <ToastContainer
        position="bottom-right"
        autoClose={3000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
}

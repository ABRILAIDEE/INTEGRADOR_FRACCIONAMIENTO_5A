import { useState, useEffect } from "react";
import profileIcon from "../../assets/usuario.png";
import BannerRes from "../../components/HeaderRes";
import SidebarRes from "../../components/SidebarRes";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";


const styles = {
  container: {
    position: "relative", // o simplemente no pongas position
    width: "100%",
    minHeight: "100vh",
    backgroundColor: "#F09560",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "sans-serif",
    left:7,
    top: 5
  },
  titleContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    width: '100%',
    maxWidth: '80%',
    margin: '30px auto',
    marginTop: 80,
  },
  subtitle: {
    fontSize: '64px',
    fontWeight: 'bold',
    flexGrow: '1',
    textAlign: 'center',
    color: '#000',
    margin: '0',
  },
  formContainer: {
    display: 'flex',
    flexDirection: 'row',
    gap: '40px',
    alignItems: 'center',
    justifyContent: 'center',
    width: '80%',
    position: 'relative',
  },
  profileIcon: {
    fontSize: '100px',
    backgroundColor: '#f0f0f0',
    width: '400px',
    height: '400px',
    borderRadius: '50%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: '-230px',
    flexShrink: 0,
    overflow: 'hidden',
  },
  profileIconImage: {
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    marginTop: '15px',
  },
  formGroup: {
    textAlign: 'left',
  },
  label: {
    fontWeight: 'bold',
    display: 'block',
    marginBottom: '5px',
    color: '#000',
  },
  input: {
    width: '180%',
    height: '20px',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    color: '#000',
    backgroundColor: '#EBEBF2',
    fontSize: '16px',
  },
  dateInput: {
    width: '180%',
    height: '20px',
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    backgroundColor: '#591202',
    fontSize: '16px',
    color: "white"
  },
  submitButtonContainer: {
    display: 'flex',
    justifyContent: 'center',
    marginTop: '20px',
  },
  editButton: {
    backgroundColor: '#591202',
    color: 'white',
    padding: '10px',
    border: 'none',
    height: '5%',
    width: '200%',
    borderRadius: '30px',
    fontSize: '20px',
    cursor: 'pointer',
    marginTop: '15px',
    marginLeft: '-200px',
    alignSelf: 'center',
  },
};


export default function ResidentProfile() {
  const [form, setForm] = useState({
    nombre: "",
    apellidos: "",
    email: "",
    edad: "",
    fechaNacimiento: "",
    direccion: "",
    telefono: "",
  });

  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();
  const baseUrl = import.meta.env.VITE_API_BASE_URL;
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const fetchResidenteData = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("Token no encontrado");

      const res = await axios.get(`${baseUrl}/api/residente/me`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = res.data.data;
      setForm({
        nombre: data.nombre || "",
        apellidos: data.apellidos || "",
        email: data.email || "",
        edad: data.edad?.toString() || "",
        fechaNacimiento: data.fechaNacimiento || "",
        direccion: `${data.house?.calle || ""}, ${data.house?.numeroCasa || ""}`,
        telefono: data.telefono || "",
      });
    } catch (error) {
      console.error("Error al obtener datos del residente", error);
      toast.error("No se pudieron cargar los datos del perfil.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResidenteData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isEditing) {
      setIsEditing(true);
      return;
    }

    // Validación
    const requiredFields = ['nombre', 'apellidos', 'email', 'edad', 'fechaNacimiento'];
    for (const field of requiredFields) {
      if (!form[field] || form[field].toString().trim() === "") {
        toast.error("Todos los campos deben estar completos.");
        return;
      }
    }

    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("Token no encontrado");

      const payload = {
        nombre: form.nombre,
        apellidos: form.apellidos,
        email: form.email,
        edad: parseInt(form.edad),
        fechaNacimiento: form.fechaNacimiento,
      };

      await axios.put(`${baseUrl}/api/residente/me`, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      toast.success("Perfil actualizado correctamente");
      setIsEditing(false);
    } catch (error) {
      console.error("Error al guardar cambios", error);
      toast.error("Error al guardar los cambios.");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  if (loading) {
    return (
      <div style={styles.container}>
        <SidebarRes />
        <BannerRes onLogout={handleLogout} />
        <p style={{ color: "white", fontSize: 18, marginTop: 100 }}>Cargando perfil...</p>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <SidebarRes />
      <BannerRes onLogout={handleLogout} />

      <div style={styles.titleContainer}>
        <h1 style={styles.subtitle}>Tu perfil</h1>
      </div>

      <div style={styles.formContainer}>
        <div style={styles.profileIcon}>
          <img src={profileIcon} alt="Profile" style={styles.profileIconImage} />
        </div>
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Nombre:</label>
            <input type="text" name="nombre" value={form.nombre} onChange={handleChange} style={styles.input} readOnly={!isEditing} />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Apellidos:</label>
            <input type="text" name="apellidos" value={form.apellidos} onChange={handleChange} style={styles.input} readOnly={!isEditing} />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Correo electrónico:</label>
            <input type="email" name="email" value={form.email} onChange={handleChange} style={styles.input} readOnly={!isEditing} />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Edad:</label>
            <input type="number" name="edad" value={form.edad} onChange={handleChange} style={styles.input} readOnly={!isEditing} />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Fecha de nacimiento:</label>
            <input type="date" name="fechaNacimiento" value={form.fechaNacimiento} onChange={handleChange} style={styles.dateInput} readOnly={!isEditing} />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Dirección:</label>
            <input type="text" name="direccion" value={form.direccion} disabled style={styles.input} />
          </div>
          <div style={styles.formGroup}>
            <label style={styles.label}>Teléfono:</label>
            <input type="tel" name="telefono" value={form.telefono} disabled style={styles.input} />
          </div>
          <div style={styles.submitButtonContainer}>
            <button type="submit" style={styles.editButton}>
              {isEditing ? "Guardar cambios" : "Editar información"}
            </button>
          </div>
        </form>
      </div>
      <ToastContainer
        position="bottom-right"
        autoClose={3000}
        hideProgressBar={false}
        closeOnClick
        pauseOnHover
        draggable
      />
    </div>
  );
}

// src/App.jsx
import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import OthersRoutes from "./screens/others/OthersRoutes";
import AdminRoutes from "./screens/admin/routes/AdminRoutes";
import ResidentRoutes from "./screens/residente/routes/ResidentRoutes";
import NotFound from "./screens/NotFound.jsx";
import Unauthorized from "./screens/Unauthorized";
import PrivateRoute from "./components/PrivateRoute";

import ProtectedRoute from "./components/ProtectedRoute";
function App() {

  return (
    <Routes>
      <Route path="/" element={<Navigate to="/scsvf/resident" />} />
      <Route path="/unauthorized" element={<Unauthorized />} />

      <Route path="/scsvf/*" element={<OthersRoutes />} />

      <Route
        path="/admin/*"
        element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminRoutes />
          </ProtectedRoute>
        }
      />
      <Route
        path="/resident/*"
        element={
          <ProtectedRoute requiredRole="RESIDENTE">
            <ResidentRoutes />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

export default App;
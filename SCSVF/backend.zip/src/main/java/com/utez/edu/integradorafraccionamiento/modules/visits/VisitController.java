package com.utez.edu.integradorafraccionamiento.modules.visits;

import com.utez.edu.integradorafraccionamiento.modules.resident.Resident;
import com.utez.edu.integradorafraccionamiento.modules.resident.ResidentRepository;
import com.utez.edu.integradorafraccionamiento.modules.resident.ResidentService;
import com.utez.edu.integradorafraccionamiento.modules.status.Status;
import com.utez.edu.integradorafraccionamiento.modules.tempVisit.TemporaryVisitToken;
import com.utez.edu.integradorafraccionamiento.modules.tempVisit.TemporaryVisitTokenRepository;
import com.utez.edu.integradorafraccionamiento.modules.tempVisit.TemporaryVisitTokenService;
import com.utez.edu.integradorafraccionamiento.modules.visits.DTO.VisitRequestDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = {"*"})
@RestController
@RequestMapping("/api/visitas")
public class VisitController {

    @Autowired
    private VisitService visitService;

    @Autowired
    private ResidentRepository residentRepository;

    @Autowired
    private ResidentService residentService;

    @Autowired
    private TemporaryVisitTokenService tokenService;

    @Autowired
    private TemporaryVisitTokenRepository tokenRepository;

    @GetMapping("")
    @Secured({"ROLE_ADMIN", "ROLE_GUARD"}) // Solo admin y guardias pueden ver todas las visitas
    public ResponseEntity<?> findAll() {
        return visitService.findAll();
    }
    @GetMapping("/me")
    @Secured("ROLE_RESIDENT")
    public ResponseEntity<?> findMyVisits(Authentication authentication) {
        return visitService.findMyVisits(authentication);
    }

    @GetMapping("/{id}")
    @Secured({"ROLE_ADMIN", "ROLE_GUARD", "ROLE_RESIDENT"}) // Residentes pueden ver sus visitas, admin y guardias todas
    public ResponseEntity<?> findById(@PathVariable long id) {
        return visitService.findById(id);
    }

    //CREAR UNA VISITA, OTORGANDO EL ID_RESIDENTE MEDIANTE AUTHENTICATION
    @PostMapping("/me")
    @Secured("ROLE_RESIDENT")
    public ResponseEntity<?> createVisitAsResident(@RequestBody VisitRequestDTO request, Authentication authentication) {
        Map<String, Object> response = new HashMap<>();

        try {
            // Obtener número de teléfono del token
            String telefono = authentication.getName();
            Optional<Resident> optionalResident = residentRepository.findByTelefono(telefono);

            if (optionalResident.isEmpty()) {
                response.put("message", "Residente no encontrado");
                response.put("status", 404);
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }

            Resident resident = optionalResident.get();

            // Aquí seteas el residentId automáticamente
            Long residentId = resident.getId();

            Visit savedVisit = visitService.saveAndReturnVisit(
                    request.getFecha(),
                    request.getHora(),
                    request.getNumeroPersonas(),
                    request.getDescripcion(),
                    request.getTipoVisita(),
                    request.getPlacasVehiculo(),
                    request.getPalabraClave(),
                    request.getNombreVisitante(),
                    residentId, // ← este se obtuvo del token
                    request.getHouseId(),
                    request.getStatusId(),
                    null, null, null // sin fotos por ahora
            );

            String qrUrl = "https://SCSVF.com/visita/" + savedVisit.getId();

            response.put("message", "Visita registrada exitosamente");
            response.put("status", 201);
            response.put("qrUrl", qrUrl);
            response.put("visitId", savedVisit.getId());
            response.put("nombreVisitante", savedVisit.getNombreVisitante());

            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (RuntimeException | IOException e) {
            e.printStackTrace();
            response.put("message", "Error: " + e.getMessage());
            response.put("status", 400);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("message", "Error inesperado: " + e.getMessage());
            response.put("status", 500);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //MANDAR JSON CRUDO, RESIDENTE_ID Y HOUSE_ID MANUALMENTE
    @PostMapping("")
    @Secured({"ROLE_RESIDENT", "ROLE_ADMIN"})
    public ResponseEntity<?> saveJson(@RequestBody VisitRequestDTO request) {
        Map<String, Object> response = new HashMap<>();

        try {
            Visit savedVisit = visitService.saveAndReturnVisit(
                    request.getFecha(),
                    request.getHora(),
                    request.getNumeroPersonas(),
                    request.getDescripcion(),
                    request.getTipoVisita(),
                    request.getPlacasVehiculo(),
                    request.getPalabraClave(),
                    request.getNombreVisitante(),
                    request.getResidentId(),
                    request.getHouseId(),
                    request.getStatusId(),
                    null, // fotoPlacas
                    null, // fotoCajuela
                    null  // fotoIne
            );

            String qrUrl = "https://SCSVF.com/api/visita/" + savedVisit.getId();

            response.put("message", "Visita registrada exitosamente");
            response.put("status", 201);
            response.put("qrUrl", qrUrl);
            response.put("visitId", savedVisit.getId());
            response.put("nombreVisitante", savedVisit.getNombreVisitante());

            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (RuntimeException | IOException e) {
            e.printStackTrace();
            response.put("message", "Error: " + e.getMessage());
            response.put("status", 400);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("message", "Error inesperado: " + e.getMessage());
            response.put("status", 500);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    //CONTROLADOR PARA USUARIO EXTERNO
    @PostMapping("/public")
    public ResponseEntity<?> createVisitAsGuest(@RequestBody VisitRequestDTO request,
                                                @RequestParam("token") String token) {
        Map<String, Object> response = new HashMap<>();

        try {
            Optional<TemporaryVisitToken> optionalToken = tokenService.validateAndConsumeToken(token);

            if (optionalToken.isEmpty()) {
                response.put("message", "Token inválido o expirado");
                return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
            }

            TemporaryVisitToken tempToken = optionalToken.get();

            // Usamos residentId y houseId del token
            Long residentId = tempToken.getResidentId();
            Long houseId = tempToken.getHouseId();

            Visit savedVisit = visitService.saveAndReturnVisit(
                    request.getFecha(),
                    request.getHora(),
                    request.getNumeroPersonas(),
                    request.getDescripcion(),
                    request.getTipoVisita(),
                    request.getPlacasVehiculo(),
                    request.getPalabraClave(),
                    request.getNombreVisitante(),
                    residentId,
                    houseId,
                    1L, // status "pendiente"
                    null, null, null
            );

            // Aquí marcamos el token como usado
            tokenService.markAsUsed(token);

            String qrUrl = "http://localhost:8080/api/visitas/" + savedVisit.getId();

            response.put("message", "Visita registrada exitosamente");
            response.put("status", 201);
            response.put("visitId", savedVisit.getId());
            response.put("nombreVisitante", savedVisit.getNombreVisitante());
            response.put("qrUrl", qrUrl);

            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (Exception e) {
            e.printStackTrace();
            response.put("message", "Error inesperado: " + e.getMessage());
            response.put("status", 500);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



/*
    // CONTROLADOR ACTUALIZADO, NO RECIBE JSON CRUDO
    @PostMapping("")
    @Secured({"ROLE_RESIDENT", "ROLE_ADMIN"})
    public ResponseEntity<?> save(@RequestParam("fecha") LocalDate fecha,
                                  @RequestParam("hora") LocalTime hora,
                                  @RequestParam("numeroPersonas") int numeroPersonas,
                                  @RequestParam("descripcion") String descripcion,
                                  @RequestParam("tipoVisita") String tipoVisita,
                                  @RequestParam("placasVehiculo") String placasVehiculo,
                                  @RequestParam(value = "palabraClave", required = false) String palabraClave,
                                  @RequestParam("nombreVisitante") String nombreVisitante,
                                  @RequestParam("residentId") Long residentId,
                                  @RequestParam("houseId") Long houseId,
                                  @RequestParam("statusId") Long statusId,
                                  @RequestPart(value = "fotoPlacas", required = false) MultipartFile fotoPlacas,
                                  @RequestPart(value = "fotoCajuela", required = false) MultipartFile fotoCajuela,
                                  @RequestPart(value = "fotoIne", required = false) MultipartFile fotoIne) {

        Map<String, Object> response = new HashMap<>();

        try {
            Visit savedVisit = visitService.saveAndReturnVisit(
                    fecha, hora, numeroPersonas, descripcion, tipoVisita, placasVehiculo,
                    palabraClave, nombreVisitante, residentId, houseId, statusId,
                    fotoPlacas, fotoCajuela, fotoIne
            );

            String qrUrl = "http://localhost:8080/api/visitas/" + savedVisit.getId();

            response.put("message", "Visita registrada exitosamente");
            response.put("status", 201);
            response.put("qrUrl", qrUrl);
            response.put("visitId", savedVisit.getId());
            response.put("nombreVisitante", savedVisit.getNombreVisitante());

            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (RuntimeException | IOException e) {
            e.printStackTrace();
            response.put("message", "Error: " + e.getMessage());
            response.put("status", 400);
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            e.printStackTrace();
            response.put("message", "Error inesperado: " + e.getMessage());
            response.put("status", 500);
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
*/


    @PatchMapping("/updateStatus/{id}")
    @Secured({"ROLE_ADMIN", "ROLE_GUARD"}) // Solo admin y guardias pueden cambiar el estado de visitas
    public ResponseEntity<?> updateStatus(@PathVariable("id") long id,
                                          @RequestBody Status nuevoEstado) {
        return visitService.updateStatus(id, nuevoEstado);
    }

    // Mostrar visitas pendientes
    @GetMapping("/pendiente")
    @Secured({"ROLE_ADMIN", "ROLE_GUARD"}) // Solo admin y guardias pueden ver las visitas pendientes
    public ResponseEntity<?> findPendingVisits() {
        return visitService.findPendingVisits();
    }

    // Mostrar visitas en progreso
    @GetMapping("/progreso")
    @Secured({"ROLE_ADMIN", "ROLE_GUARD"}) // Solo admin y guardias pueden ver las visitas pendientes
    public ResponseEntity<?> findInProgressVisits() {
        return visitService.findInProgressVisits();
    }

    //Patch aumenta el status
    @PatchMapping("/upgradeStatus/{id}")
    @Secured({"ROLE_ADMIN", "ROLE_GUARD"})
    public ResponseEntity<?> avanzarEstado(@PathVariable("id") long id) {
        return visitService.avanzarEstado(id);
    }

    @GetMapping("/pendiente/{id}")
    @Secured({"ROLE_ADMIN", "ROLE_GUARD"}) // Solo admin y guardias pueden ver visitas pendientes
    public ResponseEntity<?> findPendingVisitById(@PathVariable Long id) {
        return visitService.findPendingVisitById(id);
    }

    @GetMapping("/progreso/{id}")
    @Secured({"ROLE_ADMIN", "ROLE_GUARD"}) // Solo admin y guardias pueden ver visitas en progreso
    public ResponseEntity<?> findInProgressVisitById(@PathVariable Long id) {
        return visitService.findInProgressVisitById(id);
    }

    @GetMapping("/validar-qr/{id}")
    @Secured({"ROLE_ADMIN", "ROLE_GUARD"})
    public ResponseEntity<?> validarVisitaParaQR(@PathVariable Long id) {
        Optional<Visit> optionalVisit = visitService.findEntityById(id);

        if (optionalVisit.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", "Visita no encontrada", "status", 404));
        }

        Visit visit = optionalVisit.get();
        long statusId = visit.getStatus().getId(); // Asumiendo que Status tiene getId()

        if (statusId != 1L) { // 1 = Pendiente
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("message", "La visita no está disponible para escaneo", "status", 400));
        }

        return ResponseEntity.ok(Map.of(
                "message", "Visita válida para escaneo",
                "visitId", visit.getId(),
                "nombreVisitante", visit.getNombreVisitante(),
                "status", 200
        ));
    }


}

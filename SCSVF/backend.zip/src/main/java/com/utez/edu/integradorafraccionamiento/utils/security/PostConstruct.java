package com.utez.edu.integradorafraccionamiento.utils.security;

public @interface PostConstruct {
}

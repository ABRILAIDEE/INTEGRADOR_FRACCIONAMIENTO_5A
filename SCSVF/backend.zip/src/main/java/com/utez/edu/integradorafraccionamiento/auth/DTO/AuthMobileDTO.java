package com.utez.edu.integradorafraccionamiento.auth.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthMobileDTO {
    private String telefono;
}

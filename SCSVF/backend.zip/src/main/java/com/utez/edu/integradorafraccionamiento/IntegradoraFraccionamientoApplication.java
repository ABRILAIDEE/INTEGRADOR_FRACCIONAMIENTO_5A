package com.utez.edu.integradorafraccionamiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegradoraFraccionamientoApplication {

    public static void main(String[] args) {
        SpringApplication.run(IntegradoraFraccionamientoApplication.class, args);
    }

}
